
package Interfaz;

import AppBurguerUniverse.Inventario;
import AppBurguerUniverse.Cliente;
import AppBurguerUniverse.Comida;
import java.awt.BorderLayout;
import java.awt.Color;
import java.util.ArrayList;
import javax.swing.JPanel;
import javax.swing.table.DefaultTableModel;


public class ClienteMenu extends javax.swing.JPanel {

    ArrayList<Comida> lista = Inventario.getListatotalInventario();
    protected Cliente CA;
    DefaultTableModel modelo = new DefaultTableModel();
    int sel;
    String pedidoA;
    
    
    public ClienteMenu(Cliente cliente) {
        initComponents();
        this.CA=cliente;
        modelo.addColumn("Producto");
        modelo.addColumn("Unidades disponibles");
        modelo.addColumn("Precio por unidad");
        refrescarTabla();
    }
    private void showPanel(JPanel p){
        p.setSize(850,330);
        p.setLocation(0,0);
        this.bg.removeAll();
        this.bg.add(p, BorderLayout.CENTER);
        this.bg.revalidate();
        this.bg.repaint();
    }

    public void refrescarTabla(){
        while(modelo.getRowCount()>0){
            modelo.removeRow(0);
            
            
        }
        for(Comida x: lista){
            Object a[]= new Object[3];
            a[0]=x.getTipo();
            a[1]=x.getCant();
            a[2]=x.getPrecioUnidad();
            modelo.addRow(a);
        }
        this.tablaMenu.setModel(modelo);
    }
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        bg = new javax.swing.JPanel();
        pedido = new javax.swing.JLabel();
        jScrollPane1 = new javax.swing.JScrollPane();
        tablaMenu = new javax.swing.JTable();
        botonCarrito = new javax.swing.JPanel();
        carrito = new javax.swing.JLabel();
        botonCancelar = new javax.swing.JPanel();
        cancelar = new javax.swing.JLabel();
        textProducto = new javax.swing.JLabel();
        jSeparator1 = new javax.swing.JSeparator();
        menu1 = new javax.swing.JLabel();
        UD = new javax.swing.JLabel();
        unidadesDeseadas = new javax.swing.JTextField();
        UD1 = new javax.swing.JLabel();
        botonActualizar = new javax.swing.JPanel();
        actualizar = new javax.swing.JLabel();

        setPreferredSize(new java.awt.Dimension(850, 330));
        setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        bg.setBackground(new java.awt.Color(242, 198, 190));

        pedido.setFont(new java.awt.Font("Rockwell", 1, 24)); // NOI18N
        pedido.setForeground(new java.awt.Color(0, 0, 0));
        pedido.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        pedido.setText("Pedido");

        tablaMenu.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null}
            },
            new String [] {
                "Title 1", "Title 2", "Title 3", "Title 4"
            }
        ));
        tablaMenu.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                tablaMenuMouseClicked(evt);
            }
        });
        jScrollPane1.setViewportView(tablaMenu);

        botonCarrito.setBackground(new java.awt.Color(242, 107, 67));
        botonCarrito.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        botonCarrito.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                botonCarritoMouseClicked(evt);
            }
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                botonCarritoMouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                botonCarritoMouseExited(evt);
            }
        });

        carrito.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        carrito.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Imagenes/carrito.png"))); // NOI18N

        javax.swing.GroupLayout botonCarritoLayout = new javax.swing.GroupLayout(botonCarrito);
        botonCarrito.setLayout(botonCarritoLayout);
        botonCarritoLayout.setHorizontalGroup(
            botonCarritoLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(botonCarritoLayout.createSequentialGroup()
                .addContainerGap()
                .addComponent(carrito, javax.swing.GroupLayout.PREFERRED_SIZE, 67, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(14, Short.MAX_VALUE))
        );
        botonCarritoLayout.setVerticalGroup(
            botonCarritoLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(carrito, javax.swing.GroupLayout.DEFAULT_SIZE, 52, Short.MAX_VALUE)
        );

        botonCancelar.setBackground(new java.awt.Color(235, 107, 67));
        botonCancelar.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        botonCancelar.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                botonCancelarMouseClicked(evt);
            }
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                botonCancelarMouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                botonCancelarMouseExited(evt);
            }
        });

        cancelar.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        cancelar.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Imagenes/cancelar.png"))); // NOI18N

        javax.swing.GroupLayout botonCancelarLayout = new javax.swing.GroupLayout(botonCancelar);
        botonCancelar.setLayout(botonCancelarLayout);
        botonCancelarLayout.setHorizontalGroup(
            botonCancelarLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(cancelar, javax.swing.GroupLayout.DEFAULT_SIZE, 82, Short.MAX_VALUE)
        );
        botonCancelarLayout.setVerticalGroup(
            botonCancelarLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(cancelar, javax.swing.GroupLayout.DEFAULT_SIZE, 56, Short.MAX_VALUE)
        );

        textProducto.setFont(new java.awt.Font("Roboto", 0, 14)); // NOI18N
        textProducto.setForeground(new java.awt.Color(0, 0, 0));

        jSeparator1.setOrientation(javax.swing.SwingConstants.VERTICAL);

        menu1.setFont(new java.awt.Font("Rockwell", 1, 24)); // NOI18N
        menu1.setForeground(new java.awt.Color(0, 0, 0));
        menu1.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        menu1.setText("Menu");

        UD.setFont(new java.awt.Font("Roboto", 0, 14)); // NOI18N
        UD.setForeground(new java.awt.Color(153, 0, 102));
        UD.setText("unidades deseadas:");

        unidadesDeseadas.setBackground(new java.awt.Color(242, 198, 190));
        unidadesDeseadas.setFont(new java.awt.Font("Roboto", 1, 14)); // NOI18N
        unidadesDeseadas.setForeground(new java.awt.Color(0, 0, 0));
        unidadesDeseadas.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        unidadesDeseadas.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));
        unidadesDeseadas.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                unidadesDeseadasActionPerformed(evt);
            }
        });

        UD1.setFont(new java.awt.Font("Roboto", 0, 14)); // NOI18N
        UD1.setForeground(new java.awt.Color(153, 0, 102));
        UD1.setText("Producto:");

        botonActualizar.setBackground(new java.awt.Color(235, 107, 67));
        botonActualizar.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                botonActualizarMouseClicked(evt);
            }
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                botonActualizarMouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                botonActualizarMouseExited(evt);
            }
        });

        actualizar.setFont(new java.awt.Font("Roboto", 0, 14)); // NOI18N
        actualizar.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        actualizar.setText("Actualizar");
        actualizar.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));

        javax.swing.GroupLayout botonActualizarLayout = new javax.swing.GroupLayout(botonActualizar);
        botonActualizar.setLayout(botonActualizarLayout);
        botonActualizarLayout.setHorizontalGroup(
            botonActualizarLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(actualizar, javax.swing.GroupLayout.DEFAULT_SIZE, 100, Short.MAX_VALUE)
        );
        botonActualizarLayout.setVerticalGroup(
            botonActualizarLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(actualizar, javax.swing.GroupLayout.DEFAULT_SIZE, 37, Short.MAX_VALUE)
        );

        javax.swing.GroupLayout bgLayout = new javax.swing.GroupLayout(bg);
        bg.setLayout(bgLayout);
        bgLayout.setHorizontalGroup(
            bgLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(bgLayout.createSequentialGroup()
                .addGroup(bgLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(bgLayout.createSequentialGroup()
                        .addGap(21, 21, 21)
                        .addComponent(menu1, javax.swing.GroupLayout.PREFERRED_SIZE, 75, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 377, Short.MAX_VALUE)
                        .addComponent(botonActualizar, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, bgLayout.createSequentialGroup()
                        .addContainerGap()
                        .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 561, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jSeparator1, javax.swing.GroupLayout.PREFERRED_SIZE, 12, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(bgLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addGroup(javax.swing.GroupLayout.Alignment.LEADING, bgLayout.createSequentialGroup()
                        .addGroup(bgLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(UD1)
                            .addComponent(pedido, javax.swing.GroupLayout.PREFERRED_SIZE, 99, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(0, 0, Short.MAX_VALUE))
                    .addGroup(bgLayout.createSequentialGroup()
                        .addComponent(textProducto, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addContainerGap())
                    .addGroup(javax.swing.GroupLayout.Alignment.LEADING, bgLayout.createSequentialGroup()
                        .addComponent(UD)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(unidadesDeseadas, javax.swing.GroupLayout.PREFERRED_SIZE, 50, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                    .addGroup(bgLayout.createSequentialGroup()
                        .addComponent(botonCancelar, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 43, Short.MAX_VALUE)
                        .addComponent(botonCarrito, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(35, 35, 35))))
        );
        bgLayout.setVerticalGroup(
            bgLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(bgLayout.createSequentialGroup()
                .addContainerGap()
                .addGroup(bgLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(bgLayout.createSequentialGroup()
                        .addGroup(bgLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(bgLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                .addComponent(pedido, javax.swing.GroupLayout.DEFAULT_SIZE, 37, Short.MAX_VALUE)
                                .addComponent(menu1, javax.swing.GroupLayout.DEFAULT_SIZE, 37, Short.MAX_VALUE))
                            .addComponent(botonActualizar, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(bgLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(bgLayout.createSequentialGroup()
                                .addComponent(UD1, javax.swing.GroupLayout.PREFERRED_SIZE, 32, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(textProducto, javax.swing.GroupLayout.PREFERRED_SIZE, 34, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(18, 18, 18)
                                .addGroup(bgLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                    .addComponent(UD, javax.swing.GroupLayout.PREFERRED_SIZE, 32, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(unidadesDeseadas, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                                .addGap(70, 70, 70)
                                .addGroup(bgLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(botonCancelar, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(botonCarrito, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                            .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 256, javax.swing.GroupLayout.PREFERRED_SIZE)))
                    .addComponent(jSeparator1, javax.swing.GroupLayout.DEFAULT_SIZE, 318, Short.MAX_VALUE))
                .addContainerGap())
        );

        add(bg, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 850, 330));
    }// </editor-fold>//GEN-END:initComponents

    private void tablaMenuMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_tablaMenuMouseClicked
        sel = tablaMenu.rowAtPoint(evt.getPoint());
        textProducto.setText((String.valueOf(tablaMenu.getValueAt(sel,0))));
        pedidoA = String.valueOf(tablaMenu.getValueAt(sel,0));
    }//GEN-LAST:event_tablaMenuMouseClicked

    private void botonCarritoMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_botonCarritoMouseEntered
        botonCarrito.setBackground(new Color(240,148,177));
    }//GEN-LAST:event_botonCarritoMouseEntered

    private void botonCarritoMouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_botonCarritoMouseExited
        botonCarrito.setBackground(new Color(235,107,67));    
    }//GEN-LAST:event_botonCarritoMouseExited

    private void botonCancelarMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_botonCancelarMouseEntered
        botonCancelar.setBackground(new Color(240,148,177));
    }//GEN-LAST:event_botonCancelarMouseEntered

    private void botonCancelarMouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_botonCancelarMouseExited
        botonCancelar.setBackground(new Color(235,107,67));
    }//GEN-LAST:event_botonCancelarMouseExited

    private void botonCancelarMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_botonCancelarMouseClicked
        textProducto.setText("");
        unidadesDeseadas.setText("");
    }//GEN-LAST:event_botonCancelarMouseClicked

    private void botonCarritoMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_botonCarritoMouseClicked
        if(Inventario.verificarConInventario(pedidoA,Integer.parseInt(unidadesDeseadas.getText()))==true){
            
            CA.realizarpedido(sel+1, Integer.parseInt(unidadesDeseadas.getText()));
        }
        else{
            javax.swing.JOptionPane.showMessageDialog(null,"LA CANTIDAD DESEADA ES SUPERIOR A LA EXISTENTE\nNO SE PUDO REALIZAR EL PEDIDO");
        }
        textProducto.setText("");
        unidadesDeseadas.setText("");
        showPanel(new ClienteMenu(CA));
    }//GEN-LAST:event_botonCarritoMouseClicked

    private void unidadesDeseadasActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_unidadesDeseadasActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_unidadesDeseadasActionPerformed

    private void botonActualizarMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_botonActualizarMouseClicked
        refrescarTabla();
    }//GEN-LAST:event_botonActualizarMouseClicked

    private void botonActualizarMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_botonActualizarMouseEntered
        botonActualizar.setBackground(new Color(240,148,177));
        actualizar.setForeground(Color.BLACK);
    }//GEN-LAST:event_botonActualizarMouseEntered

    private void botonActualizarMouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_botonActualizarMouseExited
        botonActualizar.setBackground(new Color(235,107,67));
        actualizar.setForeground(Color.white);
    }//GEN-LAST:event_botonActualizarMouseExited


    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JLabel UD;
    private javax.swing.JLabel UD1;
    private javax.swing.JLabel actualizar;
    private javax.swing.JPanel bg;
    private javax.swing.JPanel botonActualizar;
    private javax.swing.JPanel botonCancelar;
    private javax.swing.JPanel botonCarrito;
    private javax.swing.JLabel cancelar;
    private javax.swing.JLabel carrito;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JSeparator jSeparator1;
    private javax.swing.JLabel menu1;
    private javax.swing.JLabel pedido;
    private javax.swing.JTable tablaMenu;
    private javax.swing.JLabel textProducto;
    private javax.swing.JTextField unidadesDeseadas;
    // End of variables declaration//GEN-END:variables
}
