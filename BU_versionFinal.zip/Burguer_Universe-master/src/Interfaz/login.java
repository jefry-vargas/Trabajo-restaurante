
package Interfaz;

import AppBurguerUniverse.Administrador;
import AppBurguerUniverse.BaseDatosBurguerUniverse;
import AppBurguerUniverse.Usuario;
import AppBurguerUniverse.Cliente;
import AppBurguerUniverse.Empleado;
import java.awt.Color;
import java.util.ArrayList;


public class login extends javax.swing.JFrame {

    int xMause, yMause;
    ArrayList<Usuario> lista = BaseDatosBurguerUniverse.getListaTotalUsuarios();
    private static Usuario CA; 
    
    public login() {
        initComponents();
        this.setLocationRelativeTo(null);
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        bg = new javax.swing.JPanel();
        barra = new javax.swing.JPanel();
        barraBoton = new javax.swing.JPanel();
        X = new javax.swing.JLabel();
        jPanel1 = new javax.swing.JPanel();
        panel = new javax.swing.JPanel();
        Usuario = new javax.swing.JLabel();
        iniciar_sesion = new javax.swing.JLabel();
        textUser = new javax.swing.JTextField();
        separador1 = new javax.swing.JSeparator();
        Contraseña = new javax.swing.JLabel();
        separador2 = new javax.swing.JSeparator();
        BotonEntrar = new javax.swing.JPanel();
        entrar = new javax.swing.JLabel();
        textContraseña = new javax.swing.JPasswordField();
        errorMsg = new javax.swing.JLabel();
        color_logo = new javax.swing.JPanel();
        imagen_logo = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setLocationByPlatform(true);
        setUndecorated(true);
        setResizable(false);

        bg.setBackground(new java.awt.Color(255, 255, 255));
        bg.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        barra.setBackground(new java.awt.Color(153, 0, 102));
        barra.addMouseMotionListener(new java.awt.event.MouseMotionAdapter() {
            public void mouseDragged(java.awt.event.MouseEvent evt) {
                barraMouseDragged(evt);
            }
        });
        barra.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mousePressed(java.awt.event.MouseEvent evt) {
                barraMousePressed(evt);
            }
        });

        barraBoton.setBackground(new java.awt.Color(153, 0, 102));
        barraBoton.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        barraBoton.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                barraBotonMouseClicked(evt);
            }
        });

        X.setBackground(new java.awt.Color(255, 255, 255));
        X.setFont(new java.awt.Font("Roboto", 1, 18)); // NOI18N
        X.setForeground(new java.awt.Color(255, 255, 255));
        X.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        X.setText("X");
        X.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                XMouseClicked(evt);
            }
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                XMouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                XMouseExited(evt);
            }
        });

        javax.swing.GroupLayout barraBotonLayout = new javax.swing.GroupLayout(barraBoton);
        barraBoton.setLayout(barraBotonLayout);
        barraBotonLayout.setHorizontalGroup(
            barraBotonLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, barraBotonLayout.createSequentialGroup()
                .addGap(0, 0, Short.MAX_VALUE)
                .addComponent(X, javax.swing.GroupLayout.PREFERRED_SIZE, 46, javax.swing.GroupLayout.PREFERRED_SIZE))
        );
        barraBotonLayout.setVerticalGroup(
            barraBotonLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(X, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );

        jPanel1.setBackground(new java.awt.Color(243, 200, 190));

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 320, Short.MAX_VALUE)
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 30, Short.MAX_VALUE)
        );

        javax.swing.GroupLayout barraLayout = new javax.swing.GroupLayout(barra);
        barra.setLayout(barraLayout);
        barraLayout.setHorizontalGroup(
            barraLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, barraLayout.createSequentialGroup()
                .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 444, Short.MAX_VALUE)
                .addComponent(barraBoton, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
        );
        barraLayout.setVerticalGroup(
            barraLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addComponent(barraBoton, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );

        bg.add(barra, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 810, 30));

        panel.setBackground(new java.awt.Color(153, 0, 102));

        Usuario.setBackground(new java.awt.Color(235, 107, 67));
        Usuario.setFont(new java.awt.Font("Roboto", 0, 18)); // NOI18N
        Usuario.setForeground(new java.awt.Color(255, 255, 255));
        Usuario.setHorizontalAlignment(javax.swing.SwingConstants.LEFT);
        Usuario.setText("Usuario");

        iniciar_sesion.setBackground(new java.awt.Color(255, 255, 255));
        iniciar_sesion.setFont(new java.awt.Font("Roboto Medium", 0, 24)); // NOI18N
        iniciar_sesion.setForeground(new java.awt.Color(255, 255, 255));
        iniciar_sesion.setText("INICIAR SESIÓN");

        textUser.setBackground(new java.awt.Color(153, 0, 102));
        textUser.setFont(new java.awt.Font("Roboto", 0, 14)); // NOI18N
        textUser.setForeground(new java.awt.Color(0, 0, 0));
        textUser.setText("Ingrese su nombre de usuario");
        textUser.setBorder(null);
        textUser.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mousePressed(java.awt.event.MouseEvent evt) {
                textUserMousePressed(evt);
            }
        });
        textUser.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                textUserActionPerformed(evt);
            }
        });

        separador1.setBackground(new java.awt.Color(255, 255, 255));
        separador1.setForeground(new java.awt.Color(255, 255, 255));

        Contraseña.setBackground(new java.awt.Color(235, 107, 67));
        Contraseña.setFont(new java.awt.Font("Roboto", 0, 18)); // NOI18N
        Contraseña.setForeground(new java.awt.Color(255, 255, 255));
        Contraseña.setHorizontalAlignment(javax.swing.SwingConstants.LEFT);
        Contraseña.setText("Contraseña");

        separador2.setBackground(new java.awt.Color(255, 255, 255));
        separador2.setForeground(new java.awt.Color(255, 255, 255));

        BotonEntrar.setBackground(new java.awt.Color(235, 107, 67));
        BotonEntrar.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                BotonEntrarMouseClicked(evt);
            }
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                BotonEntrarMouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                BotonEntrarMouseExited(evt);
            }
        });

        entrar.setFont(new java.awt.Font("Roboto Light", 0, 18)); // NOI18N
        entrar.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        entrar.setText("Entrar");
        entrar.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));

        javax.swing.GroupLayout BotonEntrarLayout = new javax.swing.GroupLayout(BotonEntrar);
        BotonEntrar.setLayout(BotonEntrarLayout);
        BotonEntrarLayout.setHorizontalGroup(
            BotonEntrarLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(entrar, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, 127, Short.MAX_VALUE)
        );
        BotonEntrarLayout.setVerticalGroup(
            BotonEntrarLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(entrar, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, 35, Short.MAX_VALUE)
        );

        textContraseña.setBackground(new java.awt.Color(153, 0, 102));
        textContraseña.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        textContraseña.setForeground(new java.awt.Color(0, 0, 0));
        textContraseña.setText("*********************");
        textContraseña.setBorder(null);
        textContraseña.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mousePressed(java.awt.event.MouseEvent evt) {
                textContraseñaMousePressed(evt);
            }
        });

        errorMsg.setFont(new java.awt.Font("Roboto Light", 0, 18)); // NOI18N
        errorMsg.setForeground(new java.awt.Color(255, 0, 0));

        javax.swing.GroupLayout panelLayout = new javax.swing.GroupLayout(panel);
        panel.setLayout(panelLayout);
        panelLayout.setHorizontalGroup(
            panelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(panelLayout.createSequentialGroup()
                .addGap(25, 25, 25)
                .addGroup(panelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(iniciar_sesion, javax.swing.GroupLayout.PREFERRED_SIZE, 183, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGroup(panelLayout.createSequentialGroup()
                        .addGap(24, 24, 24)
                        .addGroup(panelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(Usuario, javax.swing.GroupLayout.PREFERRED_SIZE, 119, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(separador1, javax.swing.GroupLayout.PREFERRED_SIZE, 406, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(Contraseña, javax.swing.GroupLayout.PREFERRED_SIZE, 119, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(textContraseña, javax.swing.GroupLayout.PREFERRED_SIZE, 329, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(separador2, javax.swing.GroupLayout.PREFERRED_SIZE, 406, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(BotonEntrar, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(textUser, javax.swing.GroupLayout.PREFERRED_SIZE, 334, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(errorMsg))))
                .addContainerGap(35, Short.MAX_VALUE))
        );
        panelLayout.setVerticalGroup(
            panelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(panelLayout.createSequentialGroup()
                .addGap(106, 106, 106)
                .addComponent(iniciar_sesion)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(Usuario, javax.swing.GroupLayout.PREFERRED_SIZE, 36, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(textUser, javax.swing.GroupLayout.PREFERRED_SIZE, 27, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(separador1, javax.swing.GroupLayout.PREFERRED_SIZE, 8, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(31, 31, 31)
                .addComponent(Contraseña, javax.swing.GroupLayout.PREFERRED_SIZE, 36, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(textContraseña, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(separador2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(23, 23, 23)
                .addComponent(errorMsg)
                .addGap(18, 18, 18)
                .addComponent(BotonEntrar, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(106, Short.MAX_VALUE))
        );

        bg.add(panel, new org.netbeans.lib.awtextra.AbsoluteConstraints(320, 0, 490, 510));

        color_logo.setBackground(new java.awt.Color(242, 198, 190));

        imagen_logo.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        imagen_logo.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Imagenes/Imagen.PNG"))); // NOI18N
        imagen_logo.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);

        javax.swing.GroupLayout color_logoLayout = new javax.swing.GroupLayout(color_logo);
        color_logo.setLayout(color_logoLayout);
        color_logoLayout.setHorizontalGroup(
            color_logoLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, color_logoLayout.createSequentialGroup()
                .addGap(0, 0, Short.MAX_VALUE)
                .addComponent(imagen_logo, javax.swing.GroupLayout.PREFERRED_SIZE, 320, javax.swing.GroupLayout.PREFERRED_SIZE))
        );
        color_logoLayout.setVerticalGroup(
            color_logoLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(color_logoLayout.createSequentialGroup()
                .addComponent(imagen_logo, javax.swing.GroupLayout.PREFERRED_SIZE, 510, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 0, Short.MAX_VALUE))
        );

        bg.add(color_logo, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, -1, -1));

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(bg, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(bg, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void BotonEntrarMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_BotonEntrarMouseEntered
        BotonEntrar.setBackground(new Color(240,148,177));
        entrar.setForeground(Color.black);
    }//GEN-LAST:event_BotonEntrarMouseEntered

    private void textUserActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_textUserActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_textUserActionPerformed

    private void barraMousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_barraMousePressed
        xMause = evt.getX();
        yMause = evt.getY();
    }//GEN-LAST:event_barraMousePressed

    private void barraMouseDragged(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_barraMouseDragged
        int x = evt.getXOnScreen();
        int y = evt.getYOnScreen();
        this.setLocation(x - xMause, y - yMause);
    }//GEN-LAST:event_barraMouseDragged

    private void XMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_XMouseClicked
        System.exit(0);
    }//GEN-LAST:event_XMouseClicked

    private void XMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_XMouseEntered
        barraBoton.setBackground(new Color(255,0,153));
        X.setForeground(Color.white);
    }//GEN-LAST:event_XMouseEntered

    private void XMouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_XMouseExited
        barraBoton.setBackground(new Color(153,0,102));
        X.setForeground(Color.black);
    }//GEN-LAST:event_XMouseExited

    private void barraBotonMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_barraBotonMouseClicked
        System.exit(0);
    }//GEN-LAST:event_barraBotonMouseClicked

    private void BotonEntrarMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_BotonEntrarMouseClicked
        CA=Administrador.devolverUsuario(lista, textUser.getText(), String.valueOf(textContraseña.getPassword()));
        int ver = BaseDatosBurguerUniverse.verifyTipoUsuario(lista,textUser.getText(), String.valueOf(textContraseña.getPassword()));
        if(ver==1){
            this.setVisible(false);
            new InterfazAdmin((Administrador)CA).setVisible(true);
        }
        else if(ver==2){
            this.setVisible(false);
            new InterfazEmpleado((Empleado)CA).setVisible(true);
    
        }
        else if(ver==3){
            this.setVisible(false);
            new InterfazCliente((Cliente)CA).setVisible(true);
            
        }
        else{
            errorMsg.setText("*Usuario y/o contraseña incorrecto/s*");
            textUser.setText("Ingrese su nombre de usuario");
            textUser.setForeground(Color.BLACK);
            textContraseña.setText("*********************");
            textContraseña.setForeground(Color.BLACK);
        }
    }//GEN-LAST:event_BotonEntrarMouseClicked

    private void BotonEntrarMouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_BotonEntrarMouseExited
        BotonEntrar.setBackground(new Color(235,107,67));
        entrar.setForeground(Color.white);
    }//GEN-LAST:event_BotonEntrarMouseExited

    private void textUserMousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_textUserMousePressed
        if(textUser.getText().equals("Ingrese su nombre de usuario")){
            textUser.setText("");
            textUser.setForeground(Color.white);
        }
        if(String.valueOf(textContraseña.getPassword()).isEmpty()){
        textContraseña.setText("*********************");
        textContraseña.setForeground(Color.BLACK);
        }
    }//GEN-LAST:event_textUserMousePressed

    private void textContraseñaMousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_textContraseñaMousePressed
        if(textUser.getText().isEmpty()){
        textUser.setText("Ingrese su nombre de usuario");
        textUser.setForeground(Color.BLACK);
        }
        if(String.valueOf(textContraseña.getPassword()).equals("*********************")){
            textContraseña.setText("");
            textContraseña.setForeground(Color.white);
        }
    }//GEN-LAST:event_textContraseñaMousePressed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(login.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(login.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(login.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(login.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new login().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JPanel BotonEntrar;
    private javax.swing.JLabel Contraseña;
    private javax.swing.JLabel Usuario;
    private javax.swing.JLabel X;
    private javax.swing.JPanel barra;
    private javax.swing.JPanel barraBoton;
    private javax.swing.JPanel bg;
    private javax.swing.JPanel color_logo;
    private javax.swing.JLabel entrar;
    private javax.swing.JLabel errorMsg;
    private javax.swing.JLabel imagen_logo;
    private javax.swing.JLabel iniciar_sesion;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel panel;
    private javax.swing.JSeparator separador1;
    private javax.swing.JSeparator separador2;
    private javax.swing.JPasswordField textContraseña;
    private javax.swing.JTextField textUser;
    // End of variables declaration//GEN-END:variables
}
