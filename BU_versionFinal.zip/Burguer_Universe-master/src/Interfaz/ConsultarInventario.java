
package Interfaz;

import AppBurguerUniverse.Administrador;
import AppBurguerUniverse.Comida;
import AppBurguerUniverse.Contabilidad;
import AppBurguerUniverse.Inventario;
import AppBurguerUniverse.Usuario;
import java.awt.BorderLayout;
import java.awt.Color;
import java.util.ArrayList;
import javax.swing.JPanel;
import javax.swing.table.DefaultTableModel;

public class ConsultarInventario extends javax.swing.JPanel {

    ArrayList<Comida> lista = Inventario.getListatotalInventario();
    protected Usuario CA;
    DefaultTableModel modelo = new DefaultTableModel();
    int sel;
    int tipoo;
    int can;
    double precio;
   
    public ConsultarInventario(Usuario user) {
        initComponents();
        this.CA=user;
        modelo.addColumn("Tipo Comida");
        modelo.addColumn("Cantidad");
        modelo.addColumn("Precio por unidad");
        refrescarTabla();
    }
    private void showPanel(JPanel p){
        p.setSize(850,330);
        p.setLocation(0,0);
        this.bg.removeAll();
        this.bg.add(p, BorderLayout.CENTER);
        this.bg.revalidate();
        this.bg.repaint();
    }

    public void refrescarTabla(){
        while(modelo.getRowCount()>0){
            modelo.removeRow(0);
            
            
        }
        for(Comida x: lista){
            Object a[]= new Object[3];
            a[0]=x.getTipo();
            a[1]=x.getCant();
            a[2]=x.getPrecioCompra();
            modelo.addRow(a);
        }
        this.tablaInventario.setModel(modelo);
    }

    
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        bg = new javax.swing.JPanel();
        jScrollPane1 = new javax.swing.JScrollPane();
        tablaInventario = new javax.swing.JTable();
        jLabel1 = new javax.swing.JLabel();
        jSeparator1 = new javax.swing.JSeparator();
        jLabel2 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        precioE = new javax.swing.JLabel();
        botonActualizar = new javax.swing.JPanel();
        actualizar = new javax.swing.JLabel();
        botonCancelar = new javax.swing.JPanel();
        cancelar = new javax.swing.JLabel();
        botonRea = new javax.swing.JPanel();
        reavastecer = new javax.swing.JLabel();
        canD = new javax.swing.JSpinner();
        aceptar = new javax.swing.JLabel();
        comidSelec = new javax.swing.JSpinner();

        setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        bg.setBackground(new java.awt.Color(242, 198, 190));

        tablaInventario.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null}
            },
            new String [] {
                "Title 1", "Title 2", "Title 3", "Title 4"
            }
        ));
        tablaInventario.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                tablaInventarioMouseClicked(evt);
            }
        });
        jScrollPane1.setViewportView(tablaInventario);

        jLabel1.setFont(new java.awt.Font("Roboto", 1, 18)); // NOI18N
        jLabel1.setForeground(new java.awt.Color(0, 0, 0));
        jLabel1.setText("Inventario Actual");

        jSeparator1.setOrientation(javax.swing.SwingConstants.VERTICAL);

        jLabel2.setFont(new java.awt.Font("Roboto", 1, 18)); // NOI18N
        jLabel2.setForeground(new java.awt.Color(0, 0, 0));
        jLabel2.setText("Restablecer inventario");

        jLabel3.setFont(new java.awt.Font("Roboto", 0, 14)); // NOI18N
        jLabel3.setForeground(new java.awt.Color(153, 0, 153));
        jLabel3.setText("Tipo de comida:");

        jLabel4.setFont(new java.awt.Font("Roboto", 0, 14)); // NOI18N
        jLabel4.setForeground(new java.awt.Color(153, 0, 153));
        jLabel4.setText("Cantidad que desea agregar:");

        jLabel5.setFont(new java.awt.Font("Roboto", 0, 14)); // NOI18N
        jLabel5.setForeground(new java.awt.Color(153, 0, 153));
        jLabel5.setText("Precio estimado:");

        precioE.setFont(new java.awt.Font("Roboto", 0, 14)); // NOI18N
        precioE.setForeground(new java.awt.Color(0, 0, 0));

        botonActualizar.setBackground(new java.awt.Color(235, 107, 67));
        botonActualizar.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                botonActualizarMouseClicked(evt);
            }
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                botonActualizarMouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                botonActualizarMouseExited(evt);
            }
        });

        actualizar.setFont(new java.awt.Font("Roboto", 0, 14)); // NOI18N
        actualizar.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        actualizar.setText("Actualizar");

        javax.swing.GroupLayout botonActualizarLayout = new javax.swing.GroupLayout(botonActualizar);
        botonActualizar.setLayout(botonActualizarLayout);
        botonActualizarLayout.setHorizontalGroup(
            botonActualizarLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(actualizar, javax.swing.GroupLayout.DEFAULT_SIZE, 100, Short.MAX_VALUE)
        );
        botonActualizarLayout.setVerticalGroup(
            botonActualizarLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(actualizar, javax.swing.GroupLayout.DEFAULT_SIZE, 26, Short.MAX_VALUE)
        );

        botonCancelar.setBackground(new java.awt.Color(235, 107, 67));
        botonCancelar.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                botonCancelarMouseClicked(evt);
            }
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                botonCancelarMouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                botonCancelarMouseExited(evt);
            }
        });

        cancelar.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        cancelar.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Imagenes/cancelar.png"))); // NOI18N

        javax.swing.GroupLayout botonCancelarLayout = new javax.swing.GroupLayout(botonCancelar);
        botonCancelar.setLayout(botonCancelarLayout);
        botonCancelarLayout.setHorizontalGroup(
            botonCancelarLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(cancelar, javax.swing.GroupLayout.DEFAULT_SIZE, 100, Short.MAX_VALUE)
        );
        botonCancelarLayout.setVerticalGroup(
            botonCancelarLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(cancelar, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );

        botonRea.setBackground(new java.awt.Color(235, 107, 67));
        botonRea.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                botonReaMouseClicked(evt);
            }
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                botonReaMouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                botonReaMouseExited(evt);
            }
        });

        reavastecer.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        reavastecer.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Imagenes/1721497 (1).png"))); // NOI18N

        javax.swing.GroupLayout botonReaLayout = new javax.swing.GroupLayout(botonRea);
        botonRea.setLayout(botonReaLayout);
        botonReaLayout.setHorizontalGroup(
            botonReaLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(reavastecer, javax.swing.GroupLayout.DEFAULT_SIZE, 100, Short.MAX_VALUE)
        );
        botonReaLayout.setVerticalGroup(
            botonReaLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(reavastecer, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );

        canD.setModel(new javax.swing.SpinnerNumberModel(0, 0, 100, 1));
        canD.setBorder(null);
        canD.setCursor(new java.awt.Cursor(java.awt.Cursor.DEFAULT_CURSOR));
        canD.addChangeListener(new javax.swing.event.ChangeListener() {
            public void stateChanged(javax.swing.event.ChangeEvent evt) {
                canDStateChanged(evt);
            }
        });

        aceptar.setFont(new java.awt.Font("Roboto", 1, 14)); // NOI18N
        aceptar.setForeground(new java.awt.Color(255, 0, 0));
        aceptar.setText("ACEPTAR");
        aceptar.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        aceptar.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                aceptarMouseClicked(evt);
            }
        });

        comidSelec.setModel(new javax.swing.SpinnerListModel(new String[] {"Hamburguesa_CarneParrilla", "Hamburguesa_Ranchera", "Hamburguesa_Casa", "Hamburguesa_Philadelpia", "PolloApanado", "Hamburguesa_PolloParrilla", "Hamburguesa_Lentejas", "Hamburguesa_Soya", "Hamburguesa_Portobello", "CocaCola", "Uva", "Sprite", "Agua_Gas", "Agua_Natural", "Corona", "Aguila", "Stella_Artois", "PorcionPequeña_PapasCasco", "PorcionMediana_PapasCasco", "PorcionGrande_PapasCasco", "PorcionPequeña_PapasCheeseBacon", "PorcionMediana_PapasCheeseBacon", "PorcionGrande_PapasCheeseBacon", "PorcionPequeña_PapasRizadas", "PorcionMediana_PapasRizadas", "PorcionGrande_PapasRizadas"}));
        comidSelec.addChangeListener(new javax.swing.event.ChangeListener() {
            public void stateChanged(javax.swing.event.ChangeEvent evt) {
                comidSelecStateChanged(evt);
            }
        });

        javax.swing.GroupLayout bgLayout = new javax.swing.GroupLayout(bg);
        bg.setLayout(bgLayout);
        bgLayout.setHorizontalGroup(
            bgLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(bgLayout.createSequentialGroup()
                .addGap(24, 24, 24)
                .addGroup(bgLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addGroup(bgLayout.createSequentialGroup()
                        .addComponent(jLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 157, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(botonActualizar, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 456, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addComponent(jSeparator1, javax.swing.GroupLayout.PREFERRED_SIZE, 18, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGroup(bgLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(bgLayout.createSequentialGroup()
                        .addGap(24, 24, 24)
                        .addGroup(bgLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(bgLayout.createSequentialGroup()
                                .addComponent(botonCancelar, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                .addComponent(botonRea, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                            .addGroup(bgLayout.createSequentialGroup()
                                .addGroup(bgLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(jLabel3, javax.swing.GroupLayout.PREFERRED_SIZE, 185, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(jLabel4, javax.swing.GroupLayout.PREFERRED_SIZE, 199, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(jLabel5, javax.swing.GroupLayout.PREFERRED_SIZE, 126, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addGroup(bgLayout.createSequentialGroup()
                                        .addComponent(canD, javax.swing.GroupLayout.PREFERRED_SIZE, 65, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addGap(28, 28, 28)
                                        .addComponent(aceptar))
                                    .addComponent(precioE, javax.swing.GroupLayout.PREFERRED_SIZE, 114, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(comidSelec, javax.swing.GroupLayout.PREFERRED_SIZE, 271, javax.swing.GroupLayout.PREFERRED_SIZE))
                                .addContainerGap(39, Short.MAX_VALUE))))
                    .addGroup(bgLayout.createSequentialGroup()
                        .addGap(18, 18, 18)
                        .addComponent(jLabel2, javax.swing.GroupLayout.PREFERRED_SIZE, 213, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addContainerGap())))
        );
        bgLayout.setVerticalGroup(
            bgLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(bgLayout.createSequentialGroup()
                .addContainerGap()
                .addGroup(bgLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(bgLayout.createSequentialGroup()
                        .addComponent(jLabel2, javax.swing.GroupLayout.PREFERRED_SIZE, 27, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jLabel3)
                        .addGap(1, 1, 1)
                        .addComponent(comidSelec, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jLabel4)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(bgLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(canD, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(aceptar))
                        .addGap(5, 5, 5)
                        .addComponent(jLabel5)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(precioE, javax.swing.GroupLayout.PREFERRED_SIZE, 25, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addGroup(bgLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addComponent(botonRea, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(botonCancelar, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                        .addGap(8, 8, 8))
                    .addComponent(jSeparator1, javax.swing.GroupLayout.Alignment.TRAILING)
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, bgLayout.createSequentialGroup()
                        .addGroup(bgLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addGroup(bgLayout.createSequentialGroup()
                                .addComponent(botonActualizar, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(0, 3, Short.MAX_VALUE)))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 275, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addGap(14, 14, 14))
        );

        add(bg, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 850, 330));
    }// </editor-fold>//GEN-END:initComponents

    private void tablaInventarioMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_tablaInventarioMouseClicked
        sel = tablaInventario.rowAtPoint(evt.getPoint());
//        comidaSelec.setText((String.valueOf(tablaInventario.getValueAt(sel,0)))); 
        for(Comida x: lista){
            if(x.getTipo().equals(String.valueOf(tablaInventario.getValueAt(sel,0))))
                precio=x.getPrecioUnidad();
        }
    }//GEN-LAST:event_tablaInventarioMouseClicked

    private void botonCancelarMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_botonCancelarMouseEntered
        botonCancelar.setBackground(new Color(240,148,177));
        cancelar.setForeground(Color.BLACK);

    }//GEN-LAST:event_botonCancelarMouseEntered

    private void botonCancelarMouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_botonCancelarMouseExited
        botonCancelar.setBackground(new Color(235,107,67));
        cancelar.setForeground(Color.white);
    }//GEN-LAST:event_botonCancelarMouseExited

    private void botonReaMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_botonReaMouseEntered
        botonRea.setBackground(new Color(240,148,177));
        reavastecer.setForeground(Color.BLACK);

    }//GEN-LAST:event_botonReaMouseEntered

    private void botonReaMouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_botonReaMouseExited
        botonRea.setBackground(new Color(235,107,67));
        reavastecer.setForeground(Color.white);
    }//GEN-LAST:event_botonReaMouseExited

    private void botonActualizarMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_botonActualizarMouseEntered
        botonActualizar.setBackground(new Color(240,148,177));
        actualizar.setForeground(Color.BLACK);
    }//GEN-LAST:event_botonActualizarMouseEntered

    private void botonActualizarMouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_botonActualizarMouseExited
        botonActualizar.setBackground(new Color(235,107,67));
        actualizar.setForeground(Color.white);
    }//GEN-LAST:event_botonActualizarMouseExited

    private void botonActualizarMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_botonActualizarMouseClicked
        refrescarTabla();
    }//GEN-LAST:event_botonActualizarMouseClicked

    private void canDStateChanged(javax.swing.event.ChangeEvent evt) {//GEN-FIRST:event_canDStateChanged
        can=Integer.parseInt(canD.getValue().toString());
    }//GEN-LAST:event_canDStateChanged

    private void aceptarMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_aceptarMouseClicked
        for(Comida x: Inventario.getListatotalInventario()){
            if(x.getTipo().equals(comidSelec.getValue().toString()))
                precio=x.getPrecioCompra();
        }
        precioE.setText(String.valueOf(can*precio));
    }//GEN-LAST:event_aceptarMouseClicked

    private void botonCancelarMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_botonCancelarMouseClicked
        comidSelec.setValue("Hamburguesa_CarneParrilla");
        canD.setValue(0);
        precioE.setText("");
    }//GEN-LAST:event_botonCancelarMouseClicked

    private void botonReaMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_botonReaMouseClicked
        if(Double.parseDouble(precioE.getText())<Contabilidad.getPresupuestoactualesBurguer()){
        Administrador.actualizarInventarioadmin(comidSelec.getValue().toString(), can);
        comidSelec.setValue("Hamburguesa_CarneParrilla");
        canD.setValue(0);
        precioE.setText("");
        refrescarTabla();
        }
        else{javax.swing.JOptionPane.showMessageDialog(null, "NO SE PUDO RESTABLECER EL INVENTARIO POR FALTA DE FONDOS");}
    }//GEN-LAST:event_botonReaMouseClicked

    private void comidSelecStateChanged(javax.swing.event.ChangeEvent evt) {//GEN-FIRST:event_comidSelecStateChanged
//        tipoo=Integer.parseInt(comidSelec.getValue().toString());
//        javax.swing.JOptionPane.showMessageDialog(null, tipoo);
    }//GEN-LAST:event_comidSelecStateChanged


    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JLabel aceptar;
    private javax.swing.JLabel actualizar;
    private javax.swing.JPanel bg;
    private javax.swing.JPanel botonActualizar;
    private javax.swing.JPanel botonCancelar;
    private javax.swing.JPanel botonRea;
    private javax.swing.JSpinner canD;
    private javax.swing.JLabel cancelar;
    private javax.swing.JSpinner comidSelec;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JSeparator jSeparator1;
    private javax.swing.JLabel precioE;
    private javax.swing.JLabel reavastecer;
    private javax.swing.JTable tablaInventario;
    // End of variables declaration//GEN-END:variables
}
