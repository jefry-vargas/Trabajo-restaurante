
package Interfaz;

import AppBurguerUniverse.BaseDatosBurguerUniverse;
import java.util.ArrayList;
import AppBurguerUniverse.Administrador;
import AppBurguerUniverse.Usuario;

public class EditarUsuario extends javax.swing.JFrame {
    
    ArrayList<Usuario> lista = BaseDatosBurguerUniverse.getListaTotalUsuarios();
    protected Usuario CA;

    public EditarUsuario(Usuario user) {
        initComponents();
        this.setLocationRelativeTo(null);
        this.CA=user;
        User.setText(CA.getNombreUsuario());
        Pass.setText(CA.getPasswordUsuario());
        Name.setText(CA.getNombre());
        lastName.setText(CA.getApellido());
        celPhone.setText(CA.getCelular());
        Gmail.setText(CA.getCorreo());
        Direccion.setText(CA.getDireccion());
    }

  
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        bg = new javax.swing.JPanel();
        userT = new javax.swing.JLabel();
        passT = new javax.swing.JLabel();
        nameT = new javax.swing.JLabel();
        lastNameT = new javax.swing.JLabel();
        celT = new javax.swing.JLabel();
        gmailT = new javax.swing.JLabel();
        dirrecionT = new javax.swing.JLabel();
        User = new javax.swing.JTextField();
        Pass = new javax.swing.JTextField();
        Name = new javax.swing.JTextField();
        lastName = new javax.swing.JTextField();
        celPhone = new javax.swing.JTextField();
        Gmail = new javax.swing.JTextField();
        Direccion = new javax.swing.JTextField();
        jPanel1 = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setLocationByPlatform(true);
        setUndecorated(true);
        setResizable(false);

        bg.setBackground(new java.awt.Color(51, 51, 51));
        bg.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        userT.setBackground(new java.awt.Color(255, 255, 255));
        userT.setForeground(new java.awt.Color(0, 153, 255));
        userT.setText("Usuario");
        bg.add(userT, new org.netbeans.lib.awtextra.AbsoluteConstraints(40, 20, -1, 20));

        passT.setBackground(new java.awt.Color(255, 255, 255));
        passT.setForeground(new java.awt.Color(0, 153, 255));
        passT.setText("Contraseña");
        bg.add(passT, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 70, -1, -1));

        nameT.setBackground(new java.awt.Color(255, 255, 255));
        nameT.setForeground(new java.awt.Color(0, 153, 255));
        nameT.setText("Nombre");
        bg.add(nameT, new org.netbeans.lib.awtextra.AbsoluteConstraints(40, 120, -1, -1));

        lastNameT.setForeground(new java.awt.Color(0, 153, 255));
        lastNameT.setText("Apellido");
        bg.add(lastNameT, new org.netbeans.lib.awtextra.AbsoluteConstraints(40, 170, -1, -1));

        celT.setForeground(new java.awt.Color(0, 153, 255));
        celT.setText("Celular");
        bg.add(celT, new org.netbeans.lib.awtextra.AbsoluteConstraints(40, 220, -1, -1));

        gmailT.setForeground(new java.awt.Color(0, 153, 255));
        gmailT.setText("Correo");
        bg.add(gmailT, new org.netbeans.lib.awtextra.AbsoluteConstraints(40, 270, -1, -1));

        dirrecionT.setForeground(new java.awt.Color(0, 153, 255));
        dirrecionT.setText("Direccion");
        bg.add(dirrecionT, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 320, -1, -1));
        bg.add(User, new org.netbeans.lib.awtextra.AbsoluteConstraints(90, 20, 190, -1));

        Pass.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                PassActionPerformed(evt);
            }
        });
        bg.add(Pass, new org.netbeans.lib.awtextra.AbsoluteConstraints(90, 70, 190, -1));
        bg.add(Name, new org.netbeans.lib.awtextra.AbsoluteConstraints(90, 120, 190, -1));
        bg.add(lastName, new org.netbeans.lib.awtextra.AbsoluteConstraints(90, 170, 190, -1));
        bg.add(celPhone, new org.netbeans.lib.awtextra.AbsoluteConstraints(90, 220, 190, -1));
        bg.add(Gmail, new org.netbeans.lib.awtextra.AbsoluteConstraints(90, 270, 190, -1));
        bg.add(Direccion, new org.netbeans.lib.awtextra.AbsoluteConstraints(90, 320, 190, -1));

        jPanel1.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        jPanel1.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jPanel1MouseClicked(evt);
            }
        });

        jLabel1.setFont(new java.awt.Font("Roboto", 1, 14)); // NOI18N
        jLabel1.setText("Aceptar");

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(29, 29, 29)
                .addComponent(jLabel1)
                .addContainerGap(30, Short.MAX_VALUE))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel1)
                .addContainerGap(7, Short.MAX_VALUE))
        );

        bg.add(jPanel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(110, 390, -1, 30));

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(bg, javax.swing.GroupLayout.DEFAULT_SIZE, 350, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(bg, javax.swing.GroupLayout.PREFERRED_SIZE, 461, javax.swing.GroupLayout.PREFERRED_SIZE)
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void PassActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_PassActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_PassActionPerformed

    private void jPanel1MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jPanel1MouseClicked
        if(Administrador.comprobarUserPorTipo(User.getText())==false){
            Administrador.modificarUsuario(BaseDatosBurguerUniverse.getListaTotalUsuarios(),CA.getNombreUsuario(),User.getText(),Pass.getText(),Name.getText(),lastName.getText(), celPhone.getText(), Gmail.getText(),Direccion.getText());
            this.setVisible(false);
        }
        else{
            javax.swing.JOptionPane.showMessageDialog(null,"ESE USUARIO YA EXISTE");
            this.setVisible(false);
        }
        
    }//GEN-LAST:event_jPanel1MouseClicked

    
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(CrearUsuario.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(CrearUsuario.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(CrearUsuario.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(CrearUsuario.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new CrearUsuario().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JTextField Direccion;
    private javax.swing.JTextField Gmail;
    private javax.swing.JTextField Name;
    private javax.swing.JTextField Pass;
    private javax.swing.JTextField User;
    private javax.swing.JPanel bg;
    private javax.swing.JTextField celPhone;
    private javax.swing.JLabel celT;
    private javax.swing.JLabel dirrecionT;
    private javax.swing.JLabel gmailT;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JTextField lastName;
    private javax.swing.JLabel lastNameT;
    private javax.swing.JLabel nameT;
    private javax.swing.JLabel passT;
    private javax.swing.JLabel userT;
    // End of variables declaration//GEN-END:variables
}
