
package Interfaz;

import AppBurguerUniverse.BaseDatosBurguerUniverse;
import AppBurguerUniverse.Cliente;
import AppBurguerUniverse.Usuario;
import java.awt.BorderLayout;
import java.awt.Color;
import java.util.ArrayList;
import javax.swing.JPanel;

public class InterfazCliente extends javax.swing.JFrame {

    ArrayList<Usuario> lista = BaseDatosBurguerUniverse.getListaTotalUsuarios();
    protected Cliente CA;
    private  clienteEditarUser panel1;
    private ClienteMenu panel2;
    private ClienteCarrito panel3;
    
    public InterfazCliente() {
        initComponents();
    }

    public InterfazCliente(Cliente cliente) {
        initComponents();
        this.CA=cliente;
        this.panel1= new clienteEditarUser(CA);
        this.panel2 = new ClienteMenu(CA);
        this.panel3 = new ClienteCarrito(CA);
        this.setLocationRelativeTo(null);
        nombreC.setText(CA.getNombre()+" "+CA.getApellido());
        showPanel(panel1);
        
    }
    
    private void showPanel(JPanel p){
        p.setSize(850,330);
        p.setLocation(0,0);
        panelinferior.removeAll();
        panelinferior.add(p, BorderLayout.CENTER);
        panelinferior.revalidate();
        panelinferior.repaint();
    }
    
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        bg = new javax.swing.JPanel();
        panelSuperior = new javax.swing.JPanel();
        barra = new javax.swing.JPanel();
        botonCerrar = new javax.swing.JPanel();
        X_exit = new javax.swing.JLabel();
        jLabel1 = new javax.swing.JLabel();
        iconoUsuario = new javax.swing.JLabel();
        nombreC = new javax.swing.JLabel();
        panelDeOpciones = new javax.swing.JPanel();
        separador1 = new javax.swing.JSeparator();
        separador2 = new javax.swing.JSeparator();
        separador3 = new javax.swing.JSeparator();
        botonCarrito = new javax.swing.JPanel();
        carrito = new javax.swing.JLabel();
        botonMenu = new javax.swing.JPanel();
        menu = new javax.swing.JLabel();
        botonEditarUsuario = new javax.swing.JPanel();
        editarUsuario = new javax.swing.JLabel();
        botonCerrarSesion = new javax.swing.JPanel();
        cerrarSesion = new javax.swing.JLabel();
        panelinferior = new javax.swing.JPanel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setLocationByPlatform(true);
        setUndecorated(true);

        bg.setBackground(new java.awt.Color(255, 255, 255));
        bg.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        panelSuperior.setBackground(new java.awt.Color(235, 107, 67));

        barra.setBackground(new java.awt.Color(235, 107, 67));

        botonCerrar.setBackground(new java.awt.Color(235, 107, 67));
        botonCerrar.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        botonCerrar.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                botonCerrarMouseClicked(evt);
            }
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                botonCerrarMouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                botonCerrarMouseExited(evt);
            }
        });

        X_exit.setBackground(new java.awt.Color(255, 255, 255));
        X_exit.setFont(new java.awt.Font("Roboto Black", 0, 24)); // NOI18N
        X_exit.setForeground(new java.awt.Color(255, 255, 255));
        X_exit.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        X_exit.setText("X");

        javax.swing.GroupLayout botonCerrarLayout = new javax.swing.GroupLayout(botonCerrar);
        botonCerrar.setLayout(botonCerrarLayout);
        botonCerrarLayout.setHorizontalGroup(
            botonCerrarLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, botonCerrarLayout.createSequentialGroup()
                .addContainerGap()
                .addComponent(X_exit, javax.swing.GroupLayout.DEFAULT_SIZE, 88, Short.MAX_VALUE))
        );
        botonCerrarLayout.setVerticalGroup(
            botonCerrarLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(X_exit, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, 41, Short.MAX_VALUE)
        );

        jLabel1.setFont(new java.awt.Font("Roboto Black", 0, 24)); // NOI18N
        jLabel1.setForeground(new java.awt.Color(0, 0, 0));
        jLabel1.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel1.setText("BURGUER UNIVERSE");

        javax.swing.GroupLayout barraLayout = new javax.swing.GroupLayout(barra);
        barra.setLayout(barraLayout);
        barraLayout.setHorizontalGroup(
            barraLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, barraLayout.createSequentialGroup()
                .addGap(274, 274, 274)
                .addComponent(jLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 313, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 169, Short.MAX_VALUE)
                .addComponent(botonCerrar, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
        );
        barraLayout.setVerticalGroup(
            barraLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(barraLayout.createSequentialGroup()
                .addComponent(botonCerrar, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 0, Short.MAX_VALUE))
            .addComponent(jLabel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );

        iconoUsuario.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Imagenes/iconoUsuario (1).png"))); // NOI18N
        iconoUsuario.setText("jLabel2");

        nombreC.setBackground(new java.awt.Color(0, 0, 0));
        nombreC.setFont(new java.awt.Font("Roboto", 1, 24)); // NOI18N
        nombreC.setForeground(new java.awt.Color(0, 0, 0));

        panelDeOpciones.setBackground(new java.awt.Color(235, 107, 67));

        separador1.setOrientation(javax.swing.SwingConstants.VERTICAL);

        separador2.setOrientation(javax.swing.SwingConstants.VERTICAL);

        separador3.setOrientation(javax.swing.SwingConstants.VERTICAL);

        botonCarrito.setBackground(new java.awt.Color(235, 107, 67));
        botonCarrito.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        botonCarrito.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                botonCarritoMouseClicked(evt);
            }
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                botonCarritoMouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                botonCarritoMouseExited(evt);
            }
        });

        carrito.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        carrito.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Imagenes/carrito.png"))); // NOI18N

        javax.swing.GroupLayout botonCarritoLayout = new javax.swing.GroupLayout(botonCarrito);
        botonCarrito.setLayout(botonCarritoLayout);
        botonCarritoLayout.setHorizontalGroup(
            botonCarritoLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(botonCarritoLayout.createSequentialGroup()
                .addGap(21, 21, 21)
                .addComponent(carrito, javax.swing.GroupLayout.PREFERRED_SIZE, 150, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(24, Short.MAX_VALUE))
        );
        botonCarritoLayout.setVerticalGroup(
            botonCarritoLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(carrito, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );

        botonMenu.setBackground(new java.awt.Color(235, 107, 67));
        botonMenu.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        botonMenu.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                botonMenuMouseClicked(evt);
            }
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                botonMenuMouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                botonMenuMouseExited(evt);
            }
        });

        menu.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        menu.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Imagenes/menu (1).png"))); // NOI18N

        javax.swing.GroupLayout botonMenuLayout = new javax.swing.GroupLayout(botonMenu);
        botonMenu.setLayout(botonMenuLayout);
        botonMenuLayout.setHorizontalGroup(
            botonMenuLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(botonMenuLayout.createSequentialGroup()
                .addGap(38, 38, 38)
                .addComponent(menu, javax.swing.GroupLayout.PREFERRED_SIZE, 150, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(54, Short.MAX_VALUE))
        );
        botonMenuLayout.setVerticalGroup(
            botonMenuLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(menu, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );

        botonEditarUsuario.setBackground(new java.awt.Color(235, 107, 67));
        botonEditarUsuario.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        botonEditarUsuario.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                botonEditarUsuarioMouseClicked(evt);
            }
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                botonEditarUsuarioMouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                botonEditarUsuarioMouseExited(evt);
            }
        });

        editarUsuario.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        editarUsuario.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Imagenes/edituser (1).png"))); // NOI18N

        javax.swing.GroupLayout botonEditarUsuarioLayout = new javax.swing.GroupLayout(botonEditarUsuario);
        botonEditarUsuario.setLayout(botonEditarUsuarioLayout);
        botonEditarUsuarioLayout.setHorizontalGroup(
            botonEditarUsuarioLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(botonEditarUsuarioLayout.createSequentialGroup()
                .addGap(15, 15, 15)
                .addComponent(editarUsuario, javax.swing.GroupLayout.PREFERRED_SIZE, 125, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(22, Short.MAX_VALUE))
        );
        botonEditarUsuarioLayout.setVerticalGroup(
            botonEditarUsuarioLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(editarUsuario, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );

        botonCerrarSesion.setBackground(new java.awt.Color(235, 107, 67));
        botonCerrarSesion.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        botonCerrarSesion.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                botonCerrarSesionMouseClicked(evt);
            }
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                botonCerrarSesionMouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                botonCerrarSesionMouseExited(evt);
            }
        });

        cerrarSesion.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        cerrarSesion.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Imagenes/cerrarSesion (1).png"))); // NOI18N

        javax.swing.GroupLayout botonCerrarSesionLayout = new javax.swing.GroupLayout(botonCerrarSesion);
        botonCerrarSesion.setLayout(botonCerrarSesionLayout);
        botonCerrarSesionLayout.setHorizontalGroup(
            botonCerrarSesionLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(botonCerrarSesionLayout.createSequentialGroup()
                .addContainerGap()
                .addComponent(cerrarSesion, javax.swing.GroupLayout.DEFAULT_SIZE, 109, Short.MAX_VALUE)
                .addContainerGap())
        );
        botonCerrarSesionLayout.setVerticalGroup(
            botonCerrarSesionLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(cerrarSesion, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );

        javax.swing.GroupLayout panelDeOpcionesLayout = new javax.swing.GroupLayout(panelDeOpciones);
        panelDeOpciones.setLayout(panelDeOpcionesLayout);
        panelDeOpcionesLayout.setHorizontalGroup(
            panelDeOpcionesLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(panelDeOpcionesLayout.createSequentialGroup()
                .addContainerGap()
                .addComponent(botonEditarUsuario, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(separador1, javax.swing.GroupLayout.PREFERRED_SIZE, 12, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(botonMenu, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(separador2, javax.swing.GroupLayout.PREFERRED_SIZE, 12, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(botonCarrito, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(separador3, javax.swing.GroupLayout.PREFERRED_SIZE, 12, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(botonCerrarSesion, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(40, Short.MAX_VALUE))
        );
        panelDeOpcionesLayout.setVerticalGroup(
            panelDeOpcionesLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(botonCarrito, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addComponent(botonMenu, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addComponent(separador1)
            .addComponent(separador2)
            .addComponent(separador3)
            .addGroup(panelDeOpcionesLayout.createSequentialGroup()
                .addComponent(botonEditarUsuario, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 0, Short.MAX_VALUE))
            .addComponent(botonCerrarSesion, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );

        javax.swing.GroupLayout panelSuperiorLayout = new javax.swing.GroupLayout(panelSuperior);
        panelSuperior.setLayout(panelSuperiorLayout);
        panelSuperiorLayout.setHorizontalGroup(
            panelSuperiorLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(barra, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addGroup(panelSuperiorLayout.createSequentialGroup()
                .addContainerGap()
                .addGroup(panelSuperiorLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(panelSuperiorLayout.createSequentialGroup()
                        .addGap(12, 12, 12)
                        .addComponent(iconoUsuario, javax.swing.GroupLayout.PREFERRED_SIZE, 55, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(nombreC, javax.swing.GroupLayout.PREFERRED_SIZE, 500, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(0, 0, Short.MAX_VALUE))
                    .addComponent(panelDeOpciones, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addContainerGap())
        );
        panelSuperiorLayout.setVerticalGroup(
            panelSuperiorLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(panelSuperiorLayout.createSequentialGroup()
                .addComponent(barra, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(panelSuperiorLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(iconoUsuario, javax.swing.GroupLayout.DEFAULT_SIZE, 56, Short.MAX_VALUE)
                    .addComponent(nombreC, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addGap(31, 31, 31)
                .addComponent(panelDeOpciones, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap())
        );

        bg.add(panelSuperior, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 850, 190));

        panelinferior.setBackground(new java.awt.Color(242, 198, 190));

        javax.swing.GroupLayout panelinferiorLayout = new javax.swing.GroupLayout(panelinferior);
        panelinferior.setLayout(panelinferiorLayout);
        panelinferiorLayout.setHorizontalGroup(
            panelinferiorLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 850, Short.MAX_VALUE)
        );
        panelinferiorLayout.setVerticalGroup(
            panelinferiorLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 330, Short.MAX_VALUE)
        );

        bg.add(panelinferior, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 190, 850, 330));

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(bg, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(bg, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void botonCerrarMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_botonCerrarMouseClicked
        System.exit(0);
    }//GEN-LAST:event_botonCerrarMouseClicked

    private void botonCerrarMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_botonCerrarMouseEntered
        botonCerrar.setBackground(new Color(240,148,177));
        X_exit.setForeground(Color.BLACK);
    }//GEN-LAST:event_botonCerrarMouseEntered

    private void botonCerrarMouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_botonCerrarMouseExited
        botonCerrar.setBackground(new Color(235,107,67));
        X_exit.setForeground(Color.white);
    }//GEN-LAST:event_botonCerrarMouseExited

    private void botonEditarUsuarioMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_botonEditarUsuarioMouseEntered
        botonEditarUsuario.setBackground(new Color(240,148,177));
        editarUsuario.setForeground(Color.BLACK);
    }//GEN-LAST:event_botonEditarUsuarioMouseEntered

    private void botonEditarUsuarioMouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_botonEditarUsuarioMouseExited
        botonEditarUsuario.setBackground(new Color(235,107,67));
        editarUsuario.setForeground(Color.white);
    }//GEN-LAST:event_botonEditarUsuarioMouseExited

    private void botonMenuMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_botonMenuMouseEntered
        botonMenu.setBackground(new Color(240,148,177));
        menu.setForeground(Color.BLACK);
    }//GEN-LAST:event_botonMenuMouseEntered

    private void botonMenuMouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_botonMenuMouseExited
        botonMenu.setBackground(new Color(235,107,67));
        menu.setForeground(Color.white);
    }//GEN-LAST:event_botonMenuMouseExited

    private void botonCarritoMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_botonCarritoMouseEntered
        botonCarrito.setBackground(new Color(240,148,177));
        carrito.setForeground(Color.BLACK);
    }//GEN-LAST:event_botonCarritoMouseEntered

    private void botonCarritoMouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_botonCarritoMouseExited
        botonCarrito.setBackground(new Color(235,107,67));
        carrito.setForeground(Color.white);
    }//GEN-LAST:event_botonCarritoMouseExited

    private void botonCerrarSesionMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_botonCerrarSesionMouseEntered
        botonCerrarSesion.setBackground(new Color(240,148,177));
        cerrarSesion.setForeground(Color.BLACK);
    }//GEN-LAST:event_botonCerrarSesionMouseEntered

    private void botonCerrarSesionMouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_botonCerrarSesionMouseExited
        botonCerrarSesion.setBackground(new Color(235,107,67));
        cerrarSesion.setForeground(Color.white);
    }//GEN-LAST:event_botonCerrarSesionMouseExited

    private void botonCerrarSesionMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_botonCerrarSesionMouseClicked
        this.setVisible(false);
        new login().setVisible(true);
    }//GEN-LAST:event_botonCerrarSesionMouseClicked

    private void botonEditarUsuarioMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_botonEditarUsuarioMouseClicked
        showPanel(panel1);
    }//GEN-LAST:event_botonEditarUsuarioMouseClicked

    private void botonMenuMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_botonMenuMouseClicked
        showPanel(panel2);
    }//GEN-LAST:event_botonMenuMouseClicked

    private void botonCarritoMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_botonCarritoMouseClicked
        showPanel(panel3);
    }//GEN-LAST:event_botonCarritoMouseClicked

    
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(InterfazCliente.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(InterfazCliente.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(InterfazCliente.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(InterfazCliente.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new InterfazCliente().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JLabel X_exit;
    private javax.swing.JPanel barra;
    private javax.swing.JPanel bg;
    private javax.swing.JPanel botonCarrito;
    private javax.swing.JPanel botonCerrar;
    private javax.swing.JPanel botonCerrarSesion;
    private javax.swing.JPanel botonEditarUsuario;
    private javax.swing.JPanel botonMenu;
    private javax.swing.JLabel carrito;
    private javax.swing.JLabel cerrarSesion;
    private javax.swing.JLabel editarUsuario;
    private javax.swing.JLabel iconoUsuario;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel menu;
    private javax.swing.JLabel nombreC;
    private javax.swing.JPanel panelDeOpciones;
    private javax.swing.JPanel panelSuperior;
    private javax.swing.JPanel panelinferior;
    private javax.swing.JSeparator separador1;
    private javax.swing.JSeparator separador2;
    private javax.swing.JSeparator separador3;
    // End of variables declaration//GEN-END:variables
}
