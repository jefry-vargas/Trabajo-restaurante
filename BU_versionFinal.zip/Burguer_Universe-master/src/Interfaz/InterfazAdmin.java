
package Interfaz;

import AppBurguerUniverse.BaseDatosBurguerUniverse;
import AppBurguerUniverse.Administrador;
import AppBurguerUniverse.Usuario;
import java.awt.BorderLayout;
import java.awt.Color;
import java.util.ArrayList;
import javax.swing.JPanel;

public class InterfazAdmin extends javax.swing.JFrame {

    ArrayList<Usuario> lista = BaseDatosBurguerUniverse.getListaTotalUsuarios();
    protected Administrador CA;
    private  adminEditarUser panel1;
    private listaUsuarios panel2;
    private ConsultarInventario panel3;
    private AdminContabilidad panel4;
    

    public InterfazAdmin(Administrador admin) {
        initComponents();
        this.CA=admin;
        this.panel1= new adminEditarUser(CA);
        this.panel2 = new listaUsuarios(CA);
        this.panel3 = new ConsultarInventario(CA);
        this.panel4 = new AdminContabilidad(CA);
        this.setLocationRelativeTo(null);
        nombreC.setText(CA.getNombre()+" "+CA.getApellido());
        showPanel(panel1);
        
    }
    
    private void showPanel(JPanel p){
        p.setSize(850,330);
        p.setLocation(0,0);
        panelinferior.removeAll();
        panelinferior.add(p, BorderLayout.CENTER);
        panelinferior.revalidate();
        panelinferior.repaint();
    }
    
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        bg = new javax.swing.JPanel();
        panelSuperior = new javax.swing.JPanel();
        barra = new javax.swing.JPanel();
        botonCerrar = new javax.swing.JPanel();
        X_exit = new javax.swing.JLabel();
        jLabel1 = new javax.swing.JLabel();
        iconoUsuario = new javax.swing.JLabel();
        nombreC = new javax.swing.JLabel();
        panelDeOpciones = new javax.swing.JPanel();
        separador1 = new javax.swing.JSeparator();
        separador2 = new javax.swing.JSeparator();
        separador3 = new javax.swing.JSeparator();
        botonInventario = new javax.swing.JPanel();
        inventario = new javax.swing.JLabel();
        botonListaUsuarios = new javax.swing.JPanel();
        listaUser = new javax.swing.JLabel();
        botonEditarUsuario = new javax.swing.JPanel();
        editarUsuario = new javax.swing.JLabel();
        botonCerrarSesion = new javax.swing.JPanel();
        cerrarSesion = new javax.swing.JLabel();
        botonContabilidad = new javax.swing.JPanel();
        contabilidad = new javax.swing.JLabel();
        separador4 = new javax.swing.JSeparator();
        panelinferior = new javax.swing.JPanel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setLocationByPlatform(true);
        setUndecorated(true);

        bg.setBackground(new java.awt.Color(255, 255, 255));
        bg.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        panelSuperior.setBackground(new java.awt.Color(235, 107, 67));

        barra.setBackground(new java.awt.Color(235, 107, 67));

        botonCerrar.setBackground(new java.awt.Color(235, 107, 67));
        botonCerrar.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        botonCerrar.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                botonCerrarMouseClicked(evt);
            }
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                botonCerrarMouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                botonCerrarMouseExited(evt);
            }
        });

        X_exit.setBackground(new java.awt.Color(255, 255, 255));
        X_exit.setFont(new java.awt.Font("Roboto Black", 0, 24)); // NOI18N
        X_exit.setForeground(new java.awt.Color(255, 255, 255));
        X_exit.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        X_exit.setText("X");

        javax.swing.GroupLayout botonCerrarLayout = new javax.swing.GroupLayout(botonCerrar);
        botonCerrar.setLayout(botonCerrarLayout);
        botonCerrarLayout.setHorizontalGroup(
            botonCerrarLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(botonCerrarLayout.createSequentialGroup()
                .addContainerGap()
                .addComponent(X_exit, javax.swing.GroupLayout.PREFERRED_SIZE, 57, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(20, Short.MAX_VALUE))
        );
        botonCerrarLayout.setVerticalGroup(
            botonCerrarLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(X_exit, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, 35, Short.MAX_VALUE)
        );

        jLabel1.setFont(new java.awt.Font("Roboto", 1, 24)); // NOI18N
        jLabel1.setForeground(new java.awt.Color(0, 0, 0));
        jLabel1.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel1.setText("BURGUER UNIVERSE");

        javax.swing.GroupLayout barraLayout = new javax.swing.GroupLayout(barra);
        barra.setLayout(barraLayout);
        barraLayout.setHorizontalGroup(
            barraLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, barraLayout.createSequentialGroup()
                .addGap(241, 241, 241)
                .addComponent(jLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 398, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 122, Short.MAX_VALUE)
                .addComponent(botonCerrar, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap())
        );
        barraLayout.setVerticalGroup(
            barraLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(barraLayout.createSequentialGroup()
                .addGap(0, 6, Short.MAX_VALUE)
                .addComponent(botonCerrar, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
            .addComponent(jLabel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );

        iconoUsuario.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        iconoUsuario.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Imagenes/78948 (1).png"))); // NOI18N

        nombreC.setBackground(new java.awt.Color(0, 0, 0));
        nombreC.setFont(new java.awt.Font("Roboto", 1, 24)); // NOI18N
        nombreC.setForeground(new java.awt.Color(0, 0, 0));

        panelDeOpciones.setBackground(new java.awt.Color(235, 107, 67));

        separador1.setOrientation(javax.swing.SwingConstants.VERTICAL);

        separador2.setOrientation(javax.swing.SwingConstants.VERTICAL);

        separador3.setOrientation(javax.swing.SwingConstants.VERTICAL);

        botonInventario.setBackground(new java.awt.Color(235, 107, 67));
        botonInventario.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        botonInventario.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                botonInventarioMouseClicked(evt);
            }
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                botonInventarioMouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                botonInventarioMouseExited(evt);
            }
        });

        inventario.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        inventario.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Imagenes/2400072 (1).png"))); // NOI18N

        javax.swing.GroupLayout botonInventarioLayout = new javax.swing.GroupLayout(botonInventario);
        botonInventario.setLayout(botonInventarioLayout);
        botonInventarioLayout.setHorizontalGroup(
            botonInventarioLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(botonInventarioLayout.createSequentialGroup()
                .addContainerGap()
                .addComponent(inventario, javax.swing.GroupLayout.DEFAULT_SIZE, 138, Short.MAX_VALUE)
                .addContainerGap())
        );
        botonInventarioLayout.setVerticalGroup(
            botonInventarioLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(inventario, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );

        botonListaUsuarios.setBackground(new java.awt.Color(235, 107, 67));
        botonListaUsuarios.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        botonListaUsuarios.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                botonListaUsuariosMouseClicked(evt);
            }
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                botonListaUsuariosMouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                botonListaUsuariosMouseExited(evt);
            }
        });

        listaUser.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        listaUser.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Imagenes/77543 (1).png"))); // NOI18N

        javax.swing.GroupLayout botonListaUsuariosLayout = new javax.swing.GroupLayout(botonListaUsuarios);
        botonListaUsuarios.setLayout(botonListaUsuariosLayout);
        botonListaUsuariosLayout.setHorizontalGroup(
            botonListaUsuariosLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(botonListaUsuariosLayout.createSequentialGroup()
                .addContainerGap()
                .addComponent(listaUser, javax.swing.GroupLayout.DEFAULT_SIZE, 138, Short.MAX_VALUE)
                .addContainerGap())
        );
        botonListaUsuariosLayout.setVerticalGroup(
            botonListaUsuariosLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(listaUser, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );

        botonEditarUsuario.setBackground(new java.awt.Color(235, 107, 67));
        botonEditarUsuario.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        botonEditarUsuario.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                botonEditarUsuarioMouseClicked(evt);
            }
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                botonEditarUsuarioMouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                botonEditarUsuarioMouseExited(evt);
            }
        });

        editarUsuario.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        editarUsuario.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Imagenes/edituser (1).png"))); // NOI18N

        javax.swing.GroupLayout botonEditarUsuarioLayout = new javax.swing.GroupLayout(botonEditarUsuario);
        botonEditarUsuario.setLayout(botonEditarUsuarioLayout);
        botonEditarUsuarioLayout.setHorizontalGroup(
            botonEditarUsuarioLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(botonEditarUsuarioLayout.createSequentialGroup()
                .addContainerGap()
                .addComponent(editarUsuario, javax.swing.GroupLayout.DEFAULT_SIZE, 138, Short.MAX_VALUE)
                .addContainerGap())
        );
        botonEditarUsuarioLayout.setVerticalGroup(
            botonEditarUsuarioLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(editarUsuario, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );

        botonCerrarSesion.setBackground(new java.awt.Color(235, 107, 67));
        botonCerrarSesion.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        botonCerrarSesion.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                botonCerrarSesionMouseClicked(evt);
            }
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                botonCerrarSesionMouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                botonCerrarSesionMouseExited(evt);
            }
        });

        cerrarSesion.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        cerrarSesion.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Imagenes/cerrarSesion (1).png"))); // NOI18N

        javax.swing.GroupLayout botonCerrarSesionLayout = new javax.swing.GroupLayout(botonCerrarSesion);
        botonCerrarSesion.setLayout(botonCerrarSesionLayout);
        botonCerrarSesionLayout.setHorizontalGroup(
            botonCerrarSesionLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(botonCerrarSesionLayout.createSequentialGroup()
                .addContainerGap()
                .addComponent(cerrarSesion, javax.swing.GroupLayout.PREFERRED_SIZE, 61, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        botonCerrarSesionLayout.setVerticalGroup(
            botonCerrarSesionLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(cerrarSesion, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );

        botonContabilidad.setBackground(new java.awt.Color(235, 107, 67));
        botonContabilidad.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                botonContabilidadMouseClicked(evt);
            }
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                botonContabilidadMouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                botonContabilidadMouseExited(evt);
            }
        });

        contabilidad.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        contabilidad.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Imagenes/accounting (1).png"))); // NOI18N

        javax.swing.GroupLayout botonContabilidadLayout = new javax.swing.GroupLayout(botonContabilidad);
        botonContabilidad.setLayout(botonContabilidadLayout);
        botonContabilidadLayout.setHorizontalGroup(
            botonContabilidadLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(contabilidad, javax.swing.GroupLayout.DEFAULT_SIZE, 150, Short.MAX_VALUE)
        );
        botonContabilidadLayout.setVerticalGroup(
            botonContabilidadLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(contabilidad, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );

        separador4.setOrientation(javax.swing.SwingConstants.VERTICAL);

        javax.swing.GroupLayout panelDeOpcionesLayout = new javax.swing.GroupLayout(panelDeOpciones);
        panelDeOpciones.setLayout(panelDeOpcionesLayout);
        panelDeOpcionesLayout.setHorizontalGroup(
            panelDeOpcionesLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(panelDeOpcionesLayout.createSequentialGroup()
                .addContainerGap()
                .addComponent(botonEditarUsuario, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(separador1, javax.swing.GroupLayout.PREFERRED_SIZE, 12, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(botonListaUsuarios, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(separador2, javax.swing.GroupLayout.PREFERRED_SIZE, 12, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(botonInventario, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(separador3, javax.swing.GroupLayout.PREFERRED_SIZE, 12, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(botonContabilidad, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(separador4, javax.swing.GroupLayout.PREFERRED_SIZE, 12, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(botonCerrarSesion, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        panelDeOpcionesLayout.setVerticalGroup(
            panelDeOpcionesLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(botonInventario, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addComponent(botonListaUsuarios, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addComponent(separador1)
            .addComponent(separador2)
            .addComponent(separador3)
            .addComponent(botonCerrarSesion, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addGroup(panelDeOpcionesLayout.createSequentialGroup()
                .addGroup(panelDeOpcionesLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                    .addComponent(separador4, javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(botonEditarUsuario, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(botonContabilidad, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addGap(0, 0, Short.MAX_VALUE))
        );

        javax.swing.GroupLayout panelSuperiorLayout = new javax.swing.GroupLayout(panelSuperior);
        panelSuperior.setLayout(panelSuperiorLayout);
        panelSuperiorLayout.setHorizontalGroup(
            panelSuperiorLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(barra, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addGroup(panelSuperiorLayout.createSequentialGroup()
                .addGap(15, 15, 15)
                .addComponent(iconoUsuario, javax.swing.GroupLayout.PREFERRED_SIZE, 55, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(nombreC, javax.swing.GroupLayout.PREFERRED_SIZE, 327, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
            .addGroup(panelSuperiorLayout.createSequentialGroup()
                .addComponent(panelDeOpciones, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 0, Short.MAX_VALUE))
        );
        panelSuperiorLayout.setVerticalGroup(
            panelSuperiorLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(panelSuperiorLayout.createSequentialGroup()
                .addComponent(barra, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(panelSuperiorLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(iconoUsuario, javax.swing.GroupLayout.DEFAULT_SIZE, 56, Short.MAX_VALUE)
                    .addComponent(nombreC, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addGap(31, 31, 31)
                .addComponent(panelDeOpciones, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap())
        );

        bg.add(panelSuperior, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 850, 190));

        panelinferior.setBackground(new java.awt.Color(242, 198, 190));

        javax.swing.GroupLayout panelinferiorLayout = new javax.swing.GroupLayout(panelinferior);
        panelinferior.setLayout(panelinferiorLayout);
        panelinferiorLayout.setHorizontalGroup(
            panelinferiorLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 850, Short.MAX_VALUE)
        );
        panelinferiorLayout.setVerticalGroup(
            panelinferiorLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 330, Short.MAX_VALUE)
        );

        bg.add(panelinferior, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 190, 850, 330));

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(bg, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(bg, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void botonCerrarMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_botonCerrarMouseClicked
        System.exit(0);
    }//GEN-LAST:event_botonCerrarMouseClicked

    private void botonCerrarMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_botonCerrarMouseEntered
        botonCerrar.setBackground(new Color(240,148,177));
        X_exit.setForeground(Color.BLACK);
    }//GEN-LAST:event_botonCerrarMouseEntered

    private void botonCerrarMouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_botonCerrarMouseExited
        botonCerrar.setBackground(new Color(235,107,67));
        X_exit.setForeground(Color.white);
    }//GEN-LAST:event_botonCerrarMouseExited

    private void botonEditarUsuarioMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_botonEditarUsuarioMouseEntered
        botonEditarUsuario.setBackground(new Color(240,148,177));
        editarUsuario.setForeground(Color.BLACK);
    }//GEN-LAST:event_botonEditarUsuarioMouseEntered

    private void botonEditarUsuarioMouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_botonEditarUsuarioMouseExited
        botonEditarUsuario.setBackground(new Color(235,107,67));
        editarUsuario.setForeground(Color.white);
    }//GEN-LAST:event_botonEditarUsuarioMouseExited

    private void botonListaUsuariosMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_botonListaUsuariosMouseEntered
        botonListaUsuarios.setBackground(new Color(240,148,177));
        listaUser.setForeground(Color.BLACK);
    }//GEN-LAST:event_botonListaUsuariosMouseEntered

    private void botonListaUsuariosMouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_botonListaUsuariosMouseExited
        botonListaUsuarios.setBackground(new Color(235,107,67));
        listaUser.setForeground(Color.white);
    }//GEN-LAST:event_botonListaUsuariosMouseExited

    private void botonInventarioMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_botonInventarioMouseEntered
        botonInventario.setBackground(new Color(240,148,177));
        inventario.setForeground(Color.BLACK);
    }//GEN-LAST:event_botonInventarioMouseEntered

    private void botonInventarioMouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_botonInventarioMouseExited
        botonInventario.setBackground(new Color(235,107,67));
        inventario.setForeground(Color.white);
    }//GEN-LAST:event_botonInventarioMouseExited

    private void botonCerrarSesionMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_botonCerrarSesionMouseEntered
        botonCerrarSesion.setBackground(new Color(240,148,177));
        cerrarSesion.setForeground(Color.BLACK);
    }//GEN-LAST:event_botonCerrarSesionMouseEntered

    private void botonCerrarSesionMouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_botonCerrarSesionMouseExited
        botonCerrarSesion.setBackground(new Color(235,107,67));
        cerrarSesion.setForeground(Color.white);
    }//GEN-LAST:event_botonCerrarSesionMouseExited

    private void botonCerrarSesionMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_botonCerrarSesionMouseClicked
        this.setVisible(false);
        new login().setVisible(true);
    }//GEN-LAST:event_botonCerrarSesionMouseClicked

    private void botonEditarUsuarioMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_botonEditarUsuarioMouseClicked
        showPanel(panel1);
    }//GEN-LAST:event_botonEditarUsuarioMouseClicked

    private void botonListaUsuariosMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_botonListaUsuariosMouseClicked
        showPanel(panel2);
    }//GEN-LAST:event_botonListaUsuariosMouseClicked

    private void botonInventarioMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_botonInventarioMouseClicked
        showPanel(panel3);
    }//GEN-LAST:event_botonInventarioMouseClicked

    private void botonContabilidadMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_botonContabilidadMouseClicked
        showPanel(panel4);
    }//GEN-LAST:event_botonContabilidadMouseClicked

    private void botonContabilidadMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_botonContabilidadMouseEntered
        botonContabilidad.setBackground(new Color(240,148,177));
        contabilidad.setForeground(Color.BLACK);
    }//GEN-LAST:event_botonContabilidadMouseEntered

    private void botonContabilidadMouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_botonContabilidadMouseExited
        botonContabilidad.setBackground(new Color(235,107,67));
        contabilidad.setForeground(Color.white);
    }//GEN-LAST:event_botonContabilidadMouseExited

    
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(InterfazCliente.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(InterfazCliente.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(InterfazCliente.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(InterfazCliente.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new InterfazCliente().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JLabel X_exit;
    private javax.swing.JPanel barra;
    private javax.swing.JPanel bg;
    private javax.swing.JPanel botonCerrar;
    private javax.swing.JPanel botonCerrarSesion;
    private javax.swing.JPanel botonContabilidad;
    private javax.swing.JPanel botonEditarUsuario;
    private javax.swing.JPanel botonInventario;
    private javax.swing.JPanel botonInventario1;
    private javax.swing.JPanel botonListaUsuarios;
    private javax.swing.JLabel cerrarSesion;
    private javax.swing.JLabel contabilidad;
    private javax.swing.JLabel editarUsuario;
    private javax.swing.JLabel iconoUsuario;
    private javax.swing.JLabel inventario;
    private javax.swing.JLabel inventario1;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel listaUser;
    private javax.swing.JLabel nombreC;
    private javax.swing.JPanel panelDeOpciones;
    private javax.swing.JPanel panelSuperior;
    private javax.swing.JPanel panelinferior;
    private javax.swing.JSeparator separador1;
    private javax.swing.JSeparator separador2;
    private javax.swing.JSeparator separador3;
    private javax.swing.JSeparator separador4;
    // End of variables declaration//GEN-END:variables
}
