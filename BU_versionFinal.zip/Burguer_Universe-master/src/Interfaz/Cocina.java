
package Interfaz;

import AppBurguerUniverse.BaseDatosBurguerUniverse;
import AppBurguerUniverse.Cliente;
import AppBurguerUniverse.Comida;
import AppBurguerUniverse.Contabilidad;
import AppBurguerUniverse.Empleado;
import AppBurguerUniverse.Facturacion;
import AppBurguerUniverse.Usuario;
import java.awt.BorderLayout;
import java.awt.Color;
import java.util.ArrayList;
import javax.swing.JPanel;
import javax.swing.table.DefaultTableModel;


public class Cocina extends javax.swing.JPanel {

    ArrayList<Facturacion> lista = Contabilidad.getListaFacturas();
    ArrayList<Usuario> listaU = BaseDatosBurguerUniverse.getListaTotalUsuarios();
    protected Empleado CA;
    protected Cliente CU;
    Facturacion F;
    int sel;
    int sel2;
    DefaultTableModel modelo1 = new DefaultTableModel();
    DefaultTableModel modelo2 = new DefaultTableModel();
    cargar hilo;
   
    public Cocina(Empleado emp) {
        
        initComponents();
        this.CA=emp;
        modelo1.addColumn("Cliente");
        modelo1.addColumn("N de factura");
        modelo1.addColumn("Precio total");
        modelo2.addColumn("Producto");
        modelo2.addColumn("Cantidad");
        modelo2.addColumn("Precio por unidad");
        refrescarTabla1();
        refrescarTabla2();
        progreso.setVisible(false);
        
        
    }
    private void showPanel(JPanel p){
        p.setSize(850,330);
        p.setLocation(0,0);
        this.bg.removeAll();
        this.bg.add(p, BorderLayout.CENTER);
        this.bg.revalidate();
        this.bg.repaint();
    }

    public void refrescarTabla1(){
        while(modelo1.getRowCount()>0){
            modelo1.removeRow(0);    
        }
        for(Facturacion x: lista){
            Object a[]= new Object[3];
            a[0]=x.getCliente();
            a[1]=x.getNumFactura();
            a[2]=x.getMontoaPagar_conIva();
            modelo1.addRow(a);
        }
        this.tablaFacturas.setModel(modelo1);
    }
    public void refrescarTabla2(){
        while(modelo2.getRowCount()>0){
            modelo2.removeRow(0);   
        }
        if(F==null){this.tablaInfoF.setModel(modelo2);}
        else{
        for(Comida x: F.getListaPedido()){
            Object a[]= new Object[3];
            a[0]=x.getTipo();
            a[1]=x.getCant();
            a[2]=x.getPrecioUnidad();
            modelo2.addRow(a);
        }
        this.tablaInfoF.setModel(modelo2);}
    }

    
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jLabel4 = new javax.swing.JLabel();
        bg = new javax.swing.JPanel();
        jScrollPane1 = new javax.swing.JScrollPane();
        tablaFacturas = new javax.swing.JTable();
        jScrollPane2 = new javax.swing.JScrollPane();
        tablaInfoF = new javax.swing.JTable();
        jSeparator1 = new javax.swing.JSeparator();
        jLabel1 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        jSeparator2 = new javax.swing.JSeparator();
        textNCliente = new javax.swing.JLabel();
        textDireccion = new javax.swing.JLabel();
        jLabel9 = new javax.swing.JLabel();
        botonActualizar = new javax.swing.JPanel();
        actualizar = new javax.swing.JLabel();
        botonCocinar = new javax.swing.JPanel();
        cocinar = new javax.swing.JLabel();
        botonEnviar = new javax.swing.JPanel();
        enviar = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        estadoP = new javax.swing.JLabel();
        progreso = new javax.swing.JProgressBar();

        jLabel4.setFont(new java.awt.Font("Roboto", 0, 14)); // NOI18N
        jLabel4.setForeground(new java.awt.Color(153, 0, 153));
        jLabel4.setText("Gastos totales:");

        setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        bg.setBackground(new java.awt.Color(242, 198, 190));

        tablaFacturas.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null}
            },
            new String [] {
                "Title 1", "Title 2", "Title 3", "Title 4"
            }
        ));
        tablaFacturas.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                tablaFacturasMouseClicked(evt);
            }
        });
        jScrollPane1.setViewportView(tablaFacturas);

        tablaInfoF.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null}
            },
            new String [] {
                "Title 1", "Title 2", "Title 3", "Title 4"
            }
        ));
        tablaInfoF.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                tablaInfoFMouseClicked(evt);
            }
        });
        jScrollPane2.setViewportView(tablaInfoF);

        jSeparator1.setOrientation(javax.swing.SwingConstants.VERTICAL);

        jLabel1.setFont(new java.awt.Font("Roboto", 1, 14)); // NOI18N
        jLabel1.setForeground(new java.awt.Color(153, 0, 153));
        jLabel1.setText("Burguer Universe");

        jLabel2.setFont(new java.awt.Font("Roboto", 0, 14)); // NOI18N
        jLabel2.setForeground(new java.awt.Color(153, 0, 153));
        jLabel2.setText("Cliente:");

        jLabel3.setFont(new java.awt.Font("Roboto", 0, 14)); // NOI18N
        jLabel3.setForeground(new java.awt.Color(153, 0, 153));
        jLabel3.setText("Dirrecion:");

        textNCliente.setFont(new java.awt.Font("Roboto", 0, 14)); // NOI18N
        textNCliente.setForeground(new java.awt.Color(0, 0, 0));

        textDireccion.setFont(new java.awt.Font("Roboto", 0, 14)); // NOI18N
        textDireccion.setForeground(new java.awt.Color(0, 0, 0));

        jLabel9.setFont(new java.awt.Font("Roboto", 1, 24)); // NOI18N
        jLabel9.setForeground(new java.awt.Color(0, 0, 0));
        jLabel9.setText("Pedidos Pendientes:");

        botonActualizar.setBackground(new java.awt.Color(235, 107, 67));
        botonActualizar.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                botonActualizarMouseClicked(evt);
            }
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                botonActualizarMouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                botonActualizarMouseExited(evt);
            }
        });

        actualizar.setFont(new java.awt.Font("Roboto", 0, 14)); // NOI18N
        actualizar.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        actualizar.setText("Actualizar");

        javax.swing.GroupLayout botonActualizarLayout = new javax.swing.GroupLayout(botonActualizar);
        botonActualizar.setLayout(botonActualizarLayout);
        botonActualizarLayout.setHorizontalGroup(
            botonActualizarLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(actualizar, javax.swing.GroupLayout.DEFAULT_SIZE, 100, Short.MAX_VALUE)
        );
        botonActualizarLayout.setVerticalGroup(
            botonActualizarLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(actualizar, javax.swing.GroupLayout.DEFAULT_SIZE, 35, Short.MAX_VALUE)
        );

        botonCocinar.setBackground(new java.awt.Color(235, 107, 67));
        botonCocinar.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                botonCocinarMouseClicked(evt);
            }
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                botonCocinarMouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                botonCocinarMouseExited(evt);
            }
        });

        cocinar.setFont(new java.awt.Font("Roboto", 0, 14)); // NOI18N
        cocinar.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        cocinar.setText("Cocinar");

        javax.swing.GroupLayout botonCocinarLayout = new javax.swing.GroupLayout(botonCocinar);
        botonCocinar.setLayout(botonCocinarLayout);
        botonCocinarLayout.setHorizontalGroup(
            botonCocinarLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(cocinar, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, 112, Short.MAX_VALUE)
        );
        botonCocinarLayout.setVerticalGroup(
            botonCocinarLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(cocinar, javax.swing.GroupLayout.DEFAULT_SIZE, 48, Short.MAX_VALUE)
        );

        botonEnviar.setBackground(new java.awt.Color(235, 107, 67));
        botonEnviar.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                botonEnviarMouseClicked(evt);
            }
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                botonEnviarMouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                botonEnviarMouseExited(evt);
            }
        });

        enviar.setFont(new java.awt.Font("Roboto", 0, 14)); // NOI18N
        enviar.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        enviar.setText("Enviar");

        javax.swing.GroupLayout botonEnviarLayout = new javax.swing.GroupLayout(botonEnviar);
        botonEnviar.setLayout(botonEnviarLayout);
        botonEnviarLayout.setHorizontalGroup(
            botonEnviarLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(enviar, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        botonEnviarLayout.setVerticalGroup(
            botonEnviarLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(enviar, javax.swing.GroupLayout.DEFAULT_SIZE, 47, Short.MAX_VALUE)
        );

        jLabel5.setFont(new java.awt.Font("Roboto", 1, 12)); // NOI18N
        jLabel5.setForeground(new java.awt.Color(153, 0, 153));
        jLabel5.setText("Esatdo Pedido:");

        estadoP.setFont(new java.awt.Font("Roboto", 0, 14)); // NOI18N
        estadoP.setForeground(new java.awt.Color(0, 0, 0));

        progreso.setBackground(new java.awt.Color(204, 204, 204));
        progreso.setForeground(new java.awt.Color(51, 0, 255));
        progreso.addChangeListener(new javax.swing.event.ChangeListener() {
            public void stateChanged(javax.swing.event.ChangeEvent evt) {
                progresoStateChanged(evt);
            }
        });

        javax.swing.GroupLayout bgLayout = new javax.swing.GroupLayout(bg);
        bg.setLayout(bgLayout);
        bgLayout.setHorizontalGroup(
            bgLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(bgLayout.createSequentialGroup()
                .addGroup(bgLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(bgLayout.createSequentialGroup()
                        .addContainerGap()
                        .addGroup(bgLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 608, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jScrollPane2)))
                    .addGroup(bgLayout.createSequentialGroup()
                        .addGap(14, 14, 14)
                        .addComponent(jLabel9, javax.swing.GroupLayout.PREFERRED_SIZE, 223, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(botonActualizar, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addGap(18, 18, 18)
                .addComponent(jSeparator1, javax.swing.GroupLayout.PREFERRED_SIZE, 18, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(bgLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(bgLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                        .addComponent(jSeparator2, javax.swing.GroupLayout.PREFERRED_SIZE, 194, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGroup(bgLayout.createSequentialGroup()
                            .addGroup(bgLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                .addComponent(jLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 152, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGroup(bgLayout.createSequentialGroup()
                                    .addComponent(jLabel2)
                                    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                    .addComponent(textNCliente, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                                .addGroup(bgLayout.createSequentialGroup()
                                    .addComponent(jLabel3, javax.swing.GroupLayout.PREFERRED_SIZE, 66, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                    .addComponent(textDireccion, javax.swing.GroupLayout.PREFERRED_SIZE, 66, javax.swing.GroupLayout.PREFERRED_SIZE)))
                            .addGap(27, 27, 27)))
                    .addGroup(bgLayout.createSequentialGroup()
                        .addGap(38, 38, 38)
                        .addGroup(bgLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addComponent(botonEnviar, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(botonCocinar, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)))
                    .addGroup(bgLayout.createSequentialGroup()
                        .addComponent(jLabel5, javax.swing.GroupLayout.PREFERRED_SIZE, 94, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(estadoP, javax.swing.GroupLayout.PREFERRED_SIZE, 79, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addComponent(progreso, javax.swing.GroupLayout.PREFERRED_SIZE, 179, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(21, 21, 21))
        );
        bgLayout.setVerticalGroup(
            bgLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(bgLayout.createSequentialGroup()
                .addContainerGap()
                .addGroup(bgLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(bgLayout.createSequentialGroup()
                        .addGroup(bgLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel9, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addGroup(bgLayout.createSequentialGroup()
                                .addComponent(botonActualizar, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(0, 0, Short.MAX_VALUE)))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 132, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(18, 18, 18)
                        .addComponent(jScrollPane2, javax.swing.GroupLayout.PREFERRED_SIZE, 101, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(37, 37, 37))
                    .addGroup(bgLayout.createSequentialGroup()
                        .addComponent(jLabel1)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addGroup(bgLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel2)
                            .addComponent(textNCliente))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addGroup(bgLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel3)
                            .addComponent(textDireccion))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jSeparator2, javax.swing.GroupLayout.PREFERRED_SIZE, 10, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(bgLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel5)
                            .addComponent(estadoP))
                        .addGap(18, 18, 18)
                        .addComponent(progreso, javax.swing.GroupLayout.PREFERRED_SIZE, 36, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(botonCocinar, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(18, 18, 18)
                        .addComponent(botonEnviar, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))))
            .addGroup(bgLayout.createSequentialGroup()
                .addComponent(jSeparator1, javax.swing.GroupLayout.PREFERRED_SIZE, 273, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 0, Short.MAX_VALUE))
        );

        add(bg, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 850, 330));
    }// </editor-fold>//GEN-END:initComponents

    private void botonActualizarMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_botonActualizarMouseEntered
        botonActualizar.setBackground(new Color(240,148,177));
        actualizar.setForeground(Color.BLACK);
    }//GEN-LAST:event_botonActualizarMouseEntered

    private void botonActualizarMouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_botonActualizarMouseExited
        botonActualizar.setBackground(new Color(235,107,67));
        actualizar.setForeground(Color.white);
    }//GEN-LAST:event_botonActualizarMouseExited

    private void botonCocinarMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_botonCocinarMouseEntered
        botonCocinar.setBackground(new Color(240,148,177));
        cocinar.setForeground(Color.BLACK);
    }//GEN-LAST:event_botonCocinarMouseEntered

    private void botonCocinarMouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_botonCocinarMouseExited
        botonCocinar.setBackground(new Color(235,107,67));
        cocinar.setForeground(Color.white);
    }//GEN-LAST:event_botonCocinarMouseExited

    private void botonActualizarMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_botonActualizarMouseClicked
        textNCliente.setText("");
        textDireccion.setText("");
        estadoP.setText("");
    }//GEN-LAST:event_botonActualizarMouseClicked

    private void tablaFacturasMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_tablaFacturasMouseClicked
        sel =tablaFacturas.rowAtPoint(evt.getPoint());
        double fac =Double.parseDouble(String.valueOf(tablaFacturas.getValueAt(sel,2)));
        for(Facturacion x: lista){
            if(x.getMontoaPagar_conIva()==fac){
                F=x;
            }
        }
        for(Usuario x:listaU){
            if(F.getNombre().equals(x.getNombre())){
                CU=(Cliente)x;
            }
        }
        textNCliente.setText(CU.getNombre());
        textDireccion.setText(CU.getDireccion());
        estadoP.setText("PENDIENTE");
        refrescarTabla2();
    }//GEN-LAST:event_tablaFacturasMouseClicked

    private void botonCocinarMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_botonCocinarMouseClicked
       if(!textNCliente.getText().equals("")){
           progreso.setVisible(true);
            hilo = new cargar(progreso);
            hilo.start();
            hilo=null;
            }
    }//GEN-LAST:event_botonCocinarMouseClicked

    private void tablaInfoFMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_tablaInfoFMouseClicked
        sel2 =tablaInfoF.rowAtPoint(evt.getPoint());
    }//GEN-LAST:event_tablaInfoFMouseClicked

    private void botonEnviarMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_botonEnviarMouseClicked
        if(modelo1.getRowCount()>0){
            estadoP.setText("ENVIADO");
            modelo1.removeRow(sel);
            modelo2.removeRow(sel);
            this.tablaFacturas.setModel(modelo1);
            this.tablaInfoF.setModel(modelo2);
            progreso.setVisible(false);}
        else{estadoP.setText("");}
    }//GEN-LAST:event_botonEnviarMouseClicked

    private void botonEnviarMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_botonEnviarMouseEntered
        botonEnviar.setBackground(new Color(240,148,177));
        enviar.setForeground(Color.BLACK);
    }//GEN-LAST:event_botonEnviarMouseEntered

    private void botonEnviarMouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_botonEnviarMouseExited
        botonEnviar.setBackground(new Color(235,107,67));
        enviar.setForeground(Color.white);  
    }//GEN-LAST:event_botonEnviarMouseExited

    private void progresoStateChanged(javax.swing.event.ChangeEvent evt) {//GEN-FIRST:event_progresoStateChanged
        if(progreso.getValue()==100){
            estadoP.setText("LISTO");
        }
    }//GEN-LAST:event_progresoStateChanged


    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JLabel actualizar;
    private javax.swing.JPanel bg;
    private javax.swing.JPanel botonActualizar;
    private javax.swing.JPanel botonCocinar;
    private javax.swing.JPanel botonEnviar;
    private javax.swing.JLabel cocinar;
    private javax.swing.JLabel enviar;
    private javax.swing.JLabel estadoP;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JSeparator jSeparator1;
    private javax.swing.JSeparator jSeparator2;
    private javax.swing.JProgressBar progreso;
    private javax.swing.JTable tablaFacturas;
    private javax.swing.JTable tablaInfoF;
    private javax.swing.JLabel textDireccion;
    private javax.swing.JLabel textNCliente;
    // End of variables declaration//GEN-END:variables
}
