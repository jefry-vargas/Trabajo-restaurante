
package Interfaz;

import javax.swing.JProgressBar;

public class cargar extends Thread{
    
    JProgressBar progreso;
    public cargar(JProgressBar progreso){
        super();
        this.progreso=progreso;
    }
    
    @Override
    public void run(){
        for(int i=1;i<=100;i++){
            progreso.setValue(i);
            pausa(50);
        }
    }
    public void pausa(int miseg){
        try{
            Thread.sleep(miseg);
        }
        catch(Exception e){}
    }

}
