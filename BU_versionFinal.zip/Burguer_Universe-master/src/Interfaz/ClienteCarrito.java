
package Interfaz;

import AppBurguerUniverse.Cliente;
import AppBurguerUniverse.Comida;
import AppBurguerUniverse.Contabilidad;
import AppBurguerUniverse.Facturacion;
import AppBurguerUniverse.medioPago;
import static AppBurguerUniverse.medioPago.EFECTIVO;
import java.awt.BorderLayout;
import java.awt.Color;
import java.util.ArrayList;
import javax.swing.JPanel;
import javax.swing.table.DefaultTableModel;


public class ClienteCarrito extends javax.swing.JPanel {

    
    protected Cliente CA;
    int sel;
    ArrayList<Comida> lista;
    DefaultTableModel modelo = new DefaultTableModel();
    medioPago pago;
    
    public ClienteCarrito(Cliente cliente) {
        initComponents();
        this.CA=cliente;
        this.lista= cliente.getListPedidoCliente();
        this.pago= CA.getTarjeta();
        modelo.addColumn("Producto");
        modelo.addColumn("Unidades");
        modelo.addColumn("Precio por unidad");
        modelo.addColumn("Precio Acumulado");
        
        
        refrescarTabla();
    }
    private void showPanel(JPanel p){
        p.setSize(850,330);
        p.setLocation(0,0);
        this.bg.removeAll();
        this.bg.add(p, BorderLayout.CENTER);
        this.bg.revalidate();
        this.bg.repaint();
    }

    public void refrescarTabla(){
        while(modelo.getRowCount()>0){
            modelo.removeRow(0);
            
            
        }
        for(Comida x: lista){
            Object a[]= new Object[4];
            a[0]=x.getTipo();
            a[1]=x.getCant();
            a[2]=x.getPrecioUnidad();
            a[3]=x.getPrecioAcumulado();
            modelo.addRow(a);
        }
        this.tablaPedido.setModel(modelo);
    }

    
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        bg = new javax.swing.JPanel();
        jScrollPane1 = new javax.swing.JScrollPane();
        tablaPedido = new javax.swing.JTable();
        carrito = new javax.swing.JLabel();
        jSeparator1 = new javax.swing.JSeparator();
        botonActualizar = new javax.swing.JPanel();
        actualizar = new javax.swing.JLabel();
        textProducto = new javax.swing.JLabel();
        jSeparator2 = new javax.swing.JSeparator();
        productSelec = new javax.swing.JLabel();
        botonEliminar = new javax.swing.JPanel();
        eliminar = new javax.swing.JLabel();
        botonComprar = new javax.swing.JPanel();
        comprar = new javax.swing.JLabel();
        botonCancelar = new javax.swing.JPanel();
        cancelar = new javax.swing.JLabel();
        valorTotal = new javax.swing.JLabel();
        textValorTotal = new javax.swing.JLabel();
        medioPago = new javax.swing.JLabel();
        textMedioPago = new javax.swing.JLabel();
        cuotas = new javax.swing.JLabel();
        textNCuotas = new javax.swing.JTextField();

        setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        bg.setBackground(new java.awt.Color(242, 198, 190));

        tablaPedido.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null}
            },
            new String [] {
                "Title 1", "Title 2", "Title 3", "Title 4"
            }
        ));
        tablaPedido.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                tablaPedidoMouseClicked(evt);
            }
        });
        jScrollPane1.setViewportView(tablaPedido);

        carrito.setBackground(new java.awt.Color(0, 0, 0));
        carrito.setFont(new java.awt.Font("Roboto", 0, 24)); // NOI18N
        carrito.setForeground(new java.awt.Color(0, 0, 0));
        carrito.setText("Carrito");

        jSeparator1.setOrientation(javax.swing.SwingConstants.VERTICAL);

        botonActualizar.setBackground(new java.awt.Color(235, 107, 67));
        botonActualizar.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        botonActualizar.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                botonActualizarMouseClicked(evt);
            }
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                botonActualizarMouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                botonActualizarMouseExited(evt);
            }
        });

        actualizar.setFont(new java.awt.Font("Roboto", 0, 14)); // NOI18N
        actualizar.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        actualizar.setText("Actualizar");

        javax.swing.GroupLayout botonActualizarLayout = new javax.swing.GroupLayout(botonActualizar);
        botonActualizar.setLayout(botonActualizarLayout);
        botonActualizarLayout.setHorizontalGroup(
            botonActualizarLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(actualizar, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, 98, Short.MAX_VALUE)
        );
        botonActualizarLayout.setVerticalGroup(
            botonActualizarLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(actualizar, javax.swing.GroupLayout.DEFAULT_SIZE, 32, Short.MAX_VALUE)
        );

        textProducto.setFont(new java.awt.Font("Roboto", 0, 14)); // NOI18N
        textProducto.setForeground(new java.awt.Color(0, 0, 0));

        productSelec.setFont(new java.awt.Font("Roboto", 0, 14)); // NOI18N
        productSelec.setForeground(new java.awt.Color(153, 0, 102));

        botonEliminar.setBackground(new java.awt.Color(235, 107, 67));
        botonEliminar.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                botonEliminarMouseClicked(evt);
            }
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                botonEliminarMouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                botonEliminarMouseExited(evt);
            }
        });

        eliminar.setFont(new java.awt.Font("Roboto", 0, 14)); // NOI18N
        eliminar.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        eliminar.setText("Eliminar");

        javax.swing.GroupLayout botonEliminarLayout = new javax.swing.GroupLayout(botonEliminar);
        botonEliminar.setLayout(botonEliminarLayout);
        botonEliminarLayout.setHorizontalGroup(
            botonEliminarLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(eliminar, javax.swing.GroupLayout.DEFAULT_SIZE, 100, Short.MAX_VALUE)
        );
        botonEliminarLayout.setVerticalGroup(
            botonEliminarLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(eliminar, javax.swing.GroupLayout.DEFAULT_SIZE, 22, Short.MAX_VALUE)
        );

        botonComprar.setBackground(new java.awt.Color(235, 107, 67));
        botonComprar.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                botonComprarMouseClicked(evt);
            }
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                botonComprarMouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                botonComprarMouseExited(evt);
            }
        });

        comprar.setFont(new java.awt.Font("Roboto", 0, 14)); // NOI18N
        comprar.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        comprar.setText("Comprar");
        comprar.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));

        javax.swing.GroupLayout botonComprarLayout = new javax.swing.GroupLayout(botonComprar);
        botonComprar.setLayout(botonComprarLayout);
        botonComprarLayout.setHorizontalGroup(
            botonComprarLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(comprar, javax.swing.GroupLayout.DEFAULT_SIZE, 92, Short.MAX_VALUE)
        );
        botonComprarLayout.setVerticalGroup(
            botonComprarLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(comprar, javax.swing.GroupLayout.DEFAULT_SIZE, 50, Short.MAX_VALUE)
        );

        botonCancelar.setBackground(new java.awt.Color(235, 107, 67));
        botonCancelar.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                botonCancelarMouseClicked(evt);
            }
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                botonCancelarMouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                botonCancelarMouseExited(evt);
            }
        });

        cancelar.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        cancelar.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Imagenes/cancelar.png"))); // NOI18N
        cancelar.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));

        javax.swing.GroupLayout botonCancelarLayout = new javax.swing.GroupLayout(botonCancelar);
        botonCancelar.setLayout(botonCancelarLayout);
        botonCancelarLayout.setHorizontalGroup(
            botonCancelarLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(cancelar, javax.swing.GroupLayout.DEFAULT_SIZE, 100, Short.MAX_VALUE)
        );
        botonCancelarLayout.setVerticalGroup(
            botonCancelarLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(cancelar, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );

        valorTotal.setFont(new java.awt.Font("Roboto", 0, 14)); // NOI18N
        valorTotal.setForeground(new java.awt.Color(153, 0, 153));
        valorTotal.setText("Valor total de la compra:");

        textValorTotal.setFont(new java.awt.Font("Roboto", 0, 18)); // NOI18N
        textValorTotal.setForeground(new java.awt.Color(0, 0, 0));

        medioPago.setFont(new java.awt.Font("Roboto", 0, 14)); // NOI18N
        medioPago.setForeground(new java.awt.Color(153, 0, 153));
        medioPago.setText("Medio de pago:");

        textMedioPago.setFont(new java.awt.Font("Roboto", 0, 14)); // NOI18N
        textMedioPago.setForeground(new java.awt.Color(0, 0, 0));

        cuotas.setFont(new java.awt.Font("Roboto", 0, 14)); // NOI18N
        cuotas.setForeground(new java.awt.Color(153, 0, 153));

        textNCuotas.setBackground(new java.awt.Color(242, 198, 190));
        textNCuotas.setFont(new java.awt.Font("Roboto", 0, 14)); // NOI18N
        textNCuotas.setForeground(new java.awt.Color(0, 0, 0));
        textNCuotas.setBorder(null);
        textNCuotas.setCursor(new java.awt.Cursor(java.awt.Cursor.TEXT_CURSOR));

        javax.swing.GroupLayout bgLayout = new javax.swing.GroupLayout(bg);
        bg.setLayout(bgLayout);
        bgLayout.setHorizontalGroup(
            bgLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(bgLayout.createSequentialGroup()
                .addGroup(bgLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addGroup(bgLayout.createSequentialGroup()
                        .addContainerGap()
                        .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 566, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(bgLayout.createSequentialGroup()
                        .addGap(25, 25, 25)
                        .addComponent(carrito, javax.swing.GroupLayout.PREFERRED_SIZE, 115, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(botonActualizar, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jSeparator1, javax.swing.GroupLayout.PREFERRED_SIZE, 11, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(bgLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(bgLayout.createSequentialGroup()
                        .addGap(0, 0, Short.MAX_VALUE)
                        .addComponent(botonEliminar, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addComponent(jSeparator2)
                    .addGroup(bgLayout.createSequentialGroup()
                        .addGroup(bgLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(productSelec)
                            .addGroup(bgLayout.createSequentialGroup()
                                .addComponent(botonCancelar, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                .addComponent(botonComprar, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addComponent(textProducto, javax.swing.GroupLayout.PREFERRED_SIZE, 205, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(textValorTotal, javax.swing.GroupLayout.PREFERRED_SIZE, 156, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addGroup(bgLayout.createSequentialGroup()
                                .addComponent(cuotas, javax.swing.GroupLayout.PREFERRED_SIZE, 79, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(textNCuotas, javax.swing.GroupLayout.PREFERRED_SIZE, 80, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addComponent(valorTotal, javax.swing.GroupLayout.PREFERRED_SIZE, 166, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addGroup(bgLayout.createSequentialGroup()
                                .addComponent(medioPago)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(textMedioPago, javax.swing.GroupLayout.PREFERRED_SIZE, 137, javax.swing.GroupLayout.PREFERRED_SIZE)))
                        .addGap(0, 12, Short.MAX_VALUE)))
                .addContainerGap())
        );
        bgLayout.setVerticalGroup(
            bgLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, bgLayout.createSequentialGroup()
                .addGroup(bgLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(bgLayout.createSequentialGroup()
                        .addContainerGap()
                        .addComponent(productSelec)
                        .addGap(12, 12, 12)
                        .addComponent(textProducto)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(botonEliminar, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jSeparator2, javax.swing.GroupLayout.PREFERRED_SIZE, 8, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(valorTotal)
                        .addGap(12, 12, 12)
                        .addComponent(textValorTotal, javax.swing.GroupLayout.PREFERRED_SIZE, 31, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(bgLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(medioPago)
                            .addComponent(textMedioPago))
                        .addGap(18, 18, 18)
                        .addGroup(bgLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(cuotas)
                            .addComponent(textNCuotas, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addGroup(bgLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(botonComprar, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(botonCancelar, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                    .addGroup(bgLayout.createSequentialGroup()
                        .addGroup(bgLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addGroup(bgLayout.createSequentialGroup()
                                .addContainerGap()
                                .addComponent(jSeparator1))
                            .addGroup(bgLayout.createSequentialGroup()
                                .addGap(18, 18, 18)
                                .addGroup(bgLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(carrito, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, bgLayout.createSequentialGroup()
                                        .addComponent(botonActualizar, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addGap(0, 0, Short.MAX_VALUE)))
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 250, javax.swing.GroupLayout.PREFERRED_SIZE)))
                        .addGap(1, 1, 1)))
                .addGap(17, 17, 17))
        );

        add(bg, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 850, 330));
    }// </editor-fold>//GEN-END:initComponents

    private void botonActualizarMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_botonActualizarMouseEntered
        botonActualizar.setBackground(new Color(240,148,177));
        actualizar.setForeground(Color.BLACK);
    }//GEN-LAST:event_botonActualizarMouseEntered

    private void botonActualizarMouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_botonActualizarMouseExited
        botonActualizar.setBackground(new Color(235,107,67));
        actualizar.setForeground(Color.white);
    }//GEN-LAST:event_botonActualizarMouseExited

    private void botonActualizarMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_botonActualizarMouseClicked
        textValorTotal.setText(String.valueOf(CA.getCostoPedido()));
        switch(pago){
            case EFECTIVO -> {textMedioPago.setText("Efectivo");
            }
            case TARJETACREDITO -> {textMedioPago.setText("Tarjeta de credito");
            cuotas.setText("N Cuotas:");
            textNCuotas.setText("1");
            }
            case TARJETADEBITO -> {textMedioPago.setText("Tarjeta de debito");
            }
        }
        refrescarTabla();
    }//GEN-LAST:event_botonActualizarMouseClicked

    private void tablaPedidoMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_tablaPedidoMouseClicked
        sel = tablaPedido.rowAtPoint(evt.getPoint());
        textProducto.setText((String.valueOf(tablaPedido.getValueAt(sel,0))));
        productSelec.setText("Producto seleccionado:");
    }//GEN-LAST:event_tablaPedidoMouseClicked

    private void botonEliminarMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_botonEliminarMouseClicked
        CA.cancelarpedido(textProducto.getText());
        refrescarTabla();
        showPanel(new ClienteCarrito(CA));
    }//GEN-LAST:event_botonEliminarMouseClicked

    private void botonEliminarMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_botonEliminarMouseEntered
        botonEliminar.setBackground(new Color(240,148,177));
        eliminar.setForeground(Color.BLACK);
    }//GEN-LAST:event_botonEliminarMouseEntered

    private void botonEliminarMouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_botonEliminarMouseExited
        botonEliminar.setBackground(new Color(235,107,67));
        eliminar.setForeground(Color.white);
    }//GEN-LAST:event_botonEliminarMouseExited

    private void botonCancelarMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_botonCancelarMouseEntered
        botonCancelar.setBackground(new Color(240,148,177));
    }//GEN-LAST:event_botonCancelarMouseEntered

    private void botonCancelarMouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_botonCancelarMouseExited
        botonCancelar.setBackground(new Color(235,107,67));
    }//GEN-LAST:event_botonCancelarMouseExited

    private void botonCancelarMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_botonCancelarMouseClicked
        CA.cancelarpedido();
        refrescarTabla();
        showPanel(new ClienteCarrito(CA));
    }//GEN-LAST:event_botonCancelarMouseClicked

    private void botonComprarMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_botonComprarMouseEntered
        botonComprar.setBackground(new Color(240,148,177));
        comprar.setForeground(Color.BLACK);
    }//GEN-LAST:event_botonComprarMouseEntered

    private void botonComprarMouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_botonComprarMouseExited
        botonComprar.setBackground(new Color(235,107,67));
        comprar.setForeground(Color.white);
    }//GEN-LAST:event_botonComprarMouseExited

    private void botonComprarMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_botonComprarMouseClicked
        if(CA.getTarjeta().getSaldodisponible()>=CA.getCostoPedido()){
            Facturacion F1 = new Facturacion(1,CA);
            F1.efectuar_pago(CA, Integer.parseInt(textNCuotas.getText()), CA.getTarjeta());
            F1.imprimirRecibo();
            Contabilidad.guardarFactura(F1);
            CA.borrarpedido();
            this.botonActualizarMouseClicked(evt); 
        }
        else{
            javax.swing.JOptionPane.showMessageDialog(null,"Saldo Insuficiente");
        }
    }//GEN-LAST:event_botonComprarMouseClicked


    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JLabel actualizar;
    private javax.swing.JPanel bg;
    private javax.swing.JPanel botonActualizar;
    private javax.swing.JPanel botonCancelar;
    private javax.swing.JPanel botonComprar;
    private javax.swing.JPanel botonEliminar;
    private javax.swing.JLabel cancelar;
    private javax.swing.JLabel carrito;
    private javax.swing.JLabel comprar;
    private javax.swing.JLabel cuotas;
    private javax.swing.JLabel eliminar;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JSeparator jSeparator1;
    private javax.swing.JSeparator jSeparator2;
    private javax.swing.JLabel medioPago;
    private javax.swing.JLabel productSelec;
    private javax.swing.JTable tablaPedido;
    private javax.swing.JLabel textMedioPago;
    private javax.swing.JTextField textNCuotas;
    private javax.swing.JLabel textProducto;
    private javax.swing.JLabel textValorTotal;
    private javax.swing.JLabel valorTotal;
    // End of variables declaration//GEN-END:variables
}
