
package Interfaz;

import AppBurguerUniverse.BaseDatosBurguerUniverse;
import AppBurguerUniverse.Administrador;
import AppBurguerUniverse.Empleado;
import AppBurguerUniverse.Usuario;
import java.awt.BorderLayout;
import java.awt.Color;
import java.util.ArrayList;
import javax.swing.JPanel;

public class empEditarUser extends javax.swing.JPanel {

    ArrayList<Usuario> lista = BaseDatosBurguerUniverse.getListaTotalUsuarios();
    protected Empleado CA;

    
    public empEditarUser(Empleado emp) {
        initComponents();
        this.CA=emp;
        mostarDatos();   
    }
    public void mostarDatos(){
        textNombre.setText(CA.getNombre());
        textLastName.setText(CA.getApellido());
        textCell.setText(CA.getCelular());
        textGmail.setText(CA.getCorreo());
        textDirec.setText(CA.getDireccion());
        textUser.setText(CA.getNombreUsuario());
        textPass.setText(CA.getPasswordUsuario());
        
    }
    private void showPanel(JPanel p){
        p.setSize(850,330);
        p.setLocation(0,0);
        this.bg.removeAll();
        this.bg.add(p, BorderLayout.CENTER);
        this.bg.revalidate();
        this.bg.repaint();
    }
    
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        bg = new javax.swing.JPanel();
        apellido = new javax.swing.JLabel();
        dirrecion = new javax.swing.JLabel();
        nombre = new javax.swing.JLabel();
        correo = new javax.swing.JLabel();
        celular = new javax.swing.JLabel();
        textNombre = new javax.swing.JTextField();
        textLastName = new javax.swing.JTextField();
        textCell = new javax.swing.JTextField();
        textGmail = new javax.swing.JTextField();
        textDirec = new javax.swing.JTextField();
        user = new javax.swing.JLabel();
        textUser = new javax.swing.JTextField();
        contraseña = new javax.swing.JLabel();
        textPass = new javax.swing.JTextField();
        jSeparator1 = new javax.swing.JSeparator();
        botonAceptar = new javax.swing.JPanel();
        guardarCambios = new javax.swing.JLabel();
        jSeparator2 = new javax.swing.JSeparator();
        datosActuales1 = new javax.swing.JLabel();
        botonActualizar = new javax.swing.JPanel();
        actualizar = new javax.swing.JLabel();
        jLabel1 = new javax.swing.JLabel();

        setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        bg.setBackground(new java.awt.Color(242, 198, 190));
        bg.setPreferredSize(new java.awt.Dimension(850, 330));

        apellido.setFont(new java.awt.Font("Roboto", 1, 18)); // NOI18N
        apellido.setForeground(new java.awt.Color(0, 0, 0));
        apellido.setText("Apellido:");

        dirrecion.setFont(new java.awt.Font("Roboto", 1, 18)); // NOI18N
        dirrecion.setForeground(new java.awt.Color(0, 0, 0));
        dirrecion.setText("Dirección:");

        nombre.setFont(new java.awt.Font("Roboto", 1, 18)); // NOI18N
        nombre.setForeground(new java.awt.Color(0, 0, 0));
        nombre.setText("Nombre:");

        correo.setFont(new java.awt.Font("Roboto", 1, 18)); // NOI18N
        correo.setForeground(new java.awt.Color(0, 0, 0));
        correo.setText("Correo:");

        celular.setFont(new java.awt.Font("Roboto", 1, 18)); // NOI18N
        celular.setForeground(new java.awt.Color(0, 0, 0));
        celular.setText("Celular:");

        textNombre.setBackground(new java.awt.Color(242, 198, 190));
        textNombre.setFont(new java.awt.Font("Roboto", 0, 14)); // NOI18N
        textNombre.setForeground(new java.awt.Color(0, 0, 0));
        textNombre.setBorder(null);
        textNombre.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mousePressed(java.awt.event.MouseEvent evt) {
                textNombreMousePressed(evt);
            }
        });

        textLastName.setBackground(new java.awt.Color(242, 198, 190));
        textLastName.setFont(new java.awt.Font("Roboto", 0, 14)); // NOI18N
        textLastName.setForeground(new java.awt.Color(0, 0, 0));
        textLastName.setBorder(null);
        textLastName.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mousePressed(java.awt.event.MouseEvent evt) {
                textLastNameMousePressed(evt);
            }
        });

        textCell.setBackground(new java.awt.Color(242, 198, 190));
        textCell.setFont(new java.awt.Font("Roboto", 0, 14)); // NOI18N
        textCell.setForeground(new java.awt.Color(0, 0, 0));
        textCell.setBorder(null);
        textCell.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mousePressed(java.awt.event.MouseEvent evt) {
                textCellMousePressed(evt);
            }
        });

        textGmail.setBackground(new java.awt.Color(242, 198, 190));
        textGmail.setFont(new java.awt.Font("Roboto", 0, 14)); // NOI18N
        textGmail.setForeground(new java.awt.Color(0, 0, 0));
        textGmail.setBorder(null);
        textGmail.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mousePressed(java.awt.event.MouseEvent evt) {
                textGmailMousePressed(evt);
            }
        });

        textDirec.setBackground(new java.awt.Color(242, 198, 190));
        textDirec.setFont(new java.awt.Font("Roboto", 0, 14)); // NOI18N
        textDirec.setForeground(new java.awt.Color(0, 0, 0));
        textDirec.setBorder(null);
        textDirec.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mousePressed(java.awt.event.MouseEvent evt) {
                textDirecMousePressed(evt);
            }
        });

        user.setFont(new java.awt.Font("Roboto", 1, 18)); // NOI18N
        user.setForeground(new java.awt.Color(0, 0, 0));
        user.setText("Usuario:");

        textUser.setBackground(new java.awt.Color(242, 198, 190));
        textUser.setFont(new java.awt.Font("Roboto", 0, 14)); // NOI18N
        textUser.setForeground(new java.awt.Color(0, 0, 0));
        textUser.setBorder(null);
        textUser.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mousePressed(java.awt.event.MouseEvent evt) {
                textUserMousePressed(evt);
            }
        });
        textUser.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                textUserActionPerformed(evt);
            }
        });

        contraseña.setFont(new java.awt.Font("Roboto", 1, 18)); // NOI18N
        contraseña.setForeground(new java.awt.Color(0, 0, 0));
        contraseña.setText("Contraseña:");

        textPass.setBackground(new java.awt.Color(242, 198, 190));
        textPass.setFont(new java.awt.Font("Roboto", 0, 14)); // NOI18N
        textPass.setForeground(new java.awt.Color(0, 0, 0));
        textPass.setBorder(null);
        textPass.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mousePressed(java.awt.event.MouseEvent evt) {
                textPassMousePressed(evt);
            }
        });

        jSeparator1.setOrientation(javax.swing.SwingConstants.VERTICAL);

        botonAceptar.setBackground(new java.awt.Color(235, 107, 67));
        botonAceptar.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        botonAceptar.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                botonAceptarMouseClicked(evt);
            }
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                botonAceptarMouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                botonAceptarMouseExited(evt);
            }
        });

        guardarCambios.setFont(new java.awt.Font("Roboto", 0, 18)); // NOI18N
        guardarCambios.setForeground(new java.awt.Color(255, 255, 255));
        guardarCambios.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        guardarCambios.setText("Guardar Cambios");

        javax.swing.GroupLayout botonAceptarLayout = new javax.swing.GroupLayout(botonAceptar);
        botonAceptar.setLayout(botonAceptarLayout);
        botonAceptarLayout.setHorizontalGroup(
            botonAceptarLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(guardarCambios, javax.swing.GroupLayout.DEFAULT_SIZE, 202, Short.MAX_VALUE)
        );
        botonAceptarLayout.setVerticalGroup(
            botonAceptarLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(guardarCambios, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );

        datosActuales1.setFont(new java.awt.Font("Roboto Medium", 0, 24)); // NOI18N
        datosActuales1.setForeground(new java.awt.Color(0, 0, 0));
        datosActuales1.setText("Datos Cliente:");

        botonActualizar.setBackground(new java.awt.Color(235, 107, 67));
        botonActualizar.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        botonActualizar.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                botonActualizarMouseClicked(evt);
            }
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                botonActualizarMouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                botonActualizarMouseExited(evt);
            }
        });

        actualizar.setFont(new java.awt.Font("Roboto", 0, 18)); // NOI18N
        actualizar.setForeground(new java.awt.Color(255, 255, 255));
        actualizar.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        actualizar.setText("Actualizar");

        javax.swing.GroupLayout botonActualizarLayout = new javax.swing.GroupLayout(botonActualizar);
        botonActualizar.setLayout(botonActualizarLayout);
        botonActualizarLayout.setHorizontalGroup(
            botonActualizarLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(actualizar, javax.swing.GroupLayout.DEFAULT_SIZE, 190, Short.MAX_VALUE)
        );
        botonActualizarLayout.setVerticalGroup(
            botonActualizarLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(actualizar, javax.swing.GroupLayout.DEFAULT_SIZE, 36, Short.MAX_VALUE)
        );

        jLabel1.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Imagenes/salsas (1).png"))); // NOI18N

        javax.swing.GroupLayout bgLayout = new javax.swing.GroupLayout(bg);
        bg.setLayout(bgLayout);
        bgLayout.setHorizontalGroup(
            bgLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(bgLayout.createSequentialGroup()
                .addGroup(bgLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(bgLayout.createSequentialGroup()
                        .addGap(14, 14, 14)
                        .addComponent(jSeparator2, javax.swing.GroupLayout.PREFERRED_SIZE, 812, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(bgLayout.createSequentialGroup()
                        .addGroup(bgLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(bgLayout.createSequentialGroup()
                                .addGap(35, 35, 35)
                                .addComponent(dirrecion)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(textDirec, javax.swing.GroupLayout.PREFERRED_SIZE, 173, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(bgLayout.createSequentialGroup()
                                .addGap(45, 45, 45)
                                .addGroup(bgLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addGroup(bgLayout.createSequentialGroup()
                                        .addGap(2, 2, 2)
                                        .addComponent(nombre)
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                        .addComponent(textNombre, javax.swing.GroupLayout.PREFERRED_SIZE, 173, javax.swing.GroupLayout.PREFERRED_SIZE))
                                    .addGroup(bgLayout.createSequentialGroup()
                                        .addGap(8, 8, 8)
                                        .addGroup(bgLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                            .addGroup(bgLayout.createSequentialGroup()
                                                .addComponent(correo, javax.swing.GroupLayout.PREFERRED_SIZE, 65, javax.swing.GroupLayout.PREFERRED_SIZE)
                                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                                .addComponent(textGmail, javax.swing.GroupLayout.PREFERRED_SIZE, 173, javax.swing.GroupLayout.PREFERRED_SIZE))
                                            .addGroup(bgLayout.createSequentialGroup()
                                                .addComponent(celular)
                                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                                .addComponent(textCell, javax.swing.GroupLayout.PREFERRED_SIZE, 173, javax.swing.GroupLayout.PREFERRED_SIZE))))
                                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, bgLayout.createSequentialGroup()
                                        .addComponent(apellido)
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                        .addComponent(textLastName, javax.swing.GroupLayout.PREFERRED_SIZE, 173, javax.swing.GroupLayout.PREFERRED_SIZE)))
                                .addGap(18, 18, 18)
                                .addGroup(bgLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                    .addGroup(bgLayout.createSequentialGroup()
                                        .addComponent(user)
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                        .addComponent(textUser, javax.swing.GroupLayout.PREFERRED_SIZE, 173, javax.swing.GroupLayout.PREFERRED_SIZE))
                                    .addGroup(bgLayout.createSequentialGroup()
                                        .addComponent(contraseña)
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                        .addComponent(textPass)))))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(jSeparator1, javax.swing.GroupLayout.PREFERRED_SIZE, 13, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(18, 18, 18)
                        .addComponent(jLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 207, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap(24, Short.MAX_VALUE))
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, bgLayout.createSequentialGroup()
                .addGap(0, 0, Short.MAX_VALUE)
                .addComponent(botonActualizar, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(55, 55, 55)
                .addComponent(botonAceptar, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(35, 35, 35))
            .addGroup(bgLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(bgLayout.createSequentialGroup()
                    .addGap(24, 24, 24)
                    .addComponent(datosActuales1, javax.swing.GroupLayout.PREFERRED_SIZE, 283, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addContainerGap(543, Short.MAX_VALUE)))
        );
        bgLayout.setVerticalGroup(
            bgLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(bgLayout.createSequentialGroup()
                .addGroup(bgLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addGroup(bgLayout.createSequentialGroup()
                        .addGap(46, 46, 46)
                        .addGroup(bgLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(bgLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                .addComponent(textNombre, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addComponent(user, javax.swing.GroupLayout.PREFERRED_SIZE, 28, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addComponent(textUser, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addComponent(nombre, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 28, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addGroup(bgLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(bgLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                .addComponent(textLastName, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addComponent(contraseña, javax.swing.GroupLayout.PREFERRED_SIZE, 28, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addComponent(textPass, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addComponent(apellido, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 29, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addGroup(bgLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(celular, javax.swing.GroupLayout.PREFERRED_SIZE, 31, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(textCell, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addGroup(bgLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(correo, javax.swing.GroupLayout.PREFERRED_SIZE, 31, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(textGmail, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addGroup(bgLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(dirrecion, javax.swing.GroupLayout.PREFERRED_SIZE, 31, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(textDirec, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                    .addGroup(bgLayout.createSequentialGroup()
                        .addGap(15, 15, 15)
                        .addComponent(jSeparator1))
                    .addGroup(bgLayout.createSequentialGroup()
                        .addGap(23, 23, 23)
                        .addComponent(jLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 209, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jSeparator2, javax.swing.GroupLayout.DEFAULT_SIZE, 4, Short.MAX_VALUE)
                .addGap(24, 24, 24)
                .addGroup(bgLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(botonActualizar, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(botonAceptar, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addGap(16, 16, 16))
            .addGroup(bgLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(bgLayout.createSequentialGroup()
                    .addGap(16, 16, 16)
                    .addComponent(datosActuales1, javax.swing.GroupLayout.PREFERRED_SIZE, 28, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addContainerGap(286, Short.MAX_VALUE)))
        );

        add(bg, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 850, 330));
    }// </editor-fold>//GEN-END:initComponents

    private void textUserActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_textUserActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_textUserActionPerformed

    private void botonAceptarMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_botonAceptarMouseEntered
        botonAceptar.setBackground(new Color(240,148,177));
        guardarCambios.setForeground(Color.black);
    }//GEN-LAST:event_botonAceptarMouseEntered

    private void botonAceptarMouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_botonAceptarMouseExited
        botonAceptar.setBackground(new Color(235,107,67));
        guardarCambios.setForeground(Color.white);
    }//GEN-LAST:event_botonAceptarMouseExited

    private void botonAceptarMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_botonAceptarMouseClicked
        Administrador.modificarUsuario(lista, CA.getNombreUsuario(),textUser.getText(), 
                textPass.getText(), textNombre.getText(), textLastName.getText(), 
                textCell.getText(), textGmail.getText(), textDirec.getText());
        mostarDatos();
        showPanel(new empEditarUser(CA));
    }//GEN-LAST:event_botonAceptarMouseClicked

    private void textNombreMousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_textNombreMousePressed
        if(textUser.getText().isEmpty()){
            textUser.setText(CA.getNombreUsuario());
            textUser.setForeground(Color.BLACK);
        }
        if(textPass.getText().isEmpty()){
        textPass.setText(CA.getPasswordUsuario());
        textPass.setForeground(Color.BLACK);
        }
        if(textNombre.getText().equals(CA.getNombre())){
        textNombre.setText("");
        textNombre.setForeground(Color.RED);
        }
        if(textLastName.getText().isEmpty()){
        textLastName.setText(CA.getApellido());
        textLastName.setForeground(Color.BLACK);
        }
        if(textCell.getText().isEmpty()){
        textCell.setText(CA.getCelular());
        textCell.setForeground(Color.BLACK);
        }
        if(textGmail.getText().isEmpty()){
        textGmail.setText(CA.getCorreo());
        textGmail.setForeground(Color.BLACK);
        }
        if(textDirec.getText().isEmpty()){
        textDirec.setText(CA.getDireccion());
        textDirec.setForeground(Color.BLACK);
        }
    }//GEN-LAST:event_textNombreMousePressed

    private void textLastNameMousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_textLastNameMousePressed
        if(textUser.getText().isEmpty()){
            textUser.setText(CA.getNombreUsuario());
            textUser.setForeground(Color.BLACK);
        }
        if(textPass.getText().isEmpty()){
        textPass.setText(CA.getPasswordUsuario());
        textPass.setForeground(Color.BLACK);
        }
        if(textNombre.getText().isEmpty()){
        textNombre.setText(CA.getNombre());
        textNombre.setForeground(Color.BLACK);
        }
        if(textLastName.getText().equals(CA.getApellido())){
        textLastName.setText("");
        textLastName.setForeground(Color.RED);
        }
        if(textCell.getText().isEmpty()){
        textCell.setText(CA.getCelular());
        textCell.setForeground(Color.BLACK);
        }
        if(textGmail.getText().isEmpty()){
        textGmail.setText(CA.getCorreo());
        textGmail.setForeground(Color.BLACK);
        }
        if(textDirec.getText().isEmpty()){
        textDirec.setText(CA.getDireccion());
        textDirec.setForeground(Color.BLACK);
        } 
    }//GEN-LAST:event_textLastNameMousePressed

    private void textCellMousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_textCellMousePressed
        if(textUser.getText().isEmpty()){
            textUser.setText(CA.getNombreUsuario());
            textUser.setForeground(Color.BLACK);
        }
        if(textPass.getText().isEmpty()){
        textPass.setText(CA.getPasswordUsuario());
        textPass.setForeground(Color.BLACK);
        }
        if(textNombre.getText().isEmpty()){
        textNombre.setText(CA.getNombre());
        textNombre.setForeground(Color.BLACK);
        }
        if(textLastName.getText().isEmpty()){
        textLastName.setText(CA.getApellido());
        textLastName.setForeground(Color.BLACK);
        }
        if(textCell.getText().equals(CA.getCelular())){
        textCell.setText("");
        textCell.setForeground(Color.RED);
        }
        if(textGmail.getText().isEmpty()){
        textGmail.setText(CA.getCorreo());
        textGmail.setForeground(Color.BLACK);
        }
        if(textDirec.getText().isEmpty()){
        textDirec.setText(CA.getDireccion());
        textDirec.setForeground(Color.BLACK);
        }   
    }//GEN-LAST:event_textCellMousePressed

    private void textGmailMousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_textGmailMousePressed
        if(textUser.getText().isEmpty()){
            textUser.setText(CA.getNombreUsuario());
            textUser.setForeground(Color.BLACK);
        }
        if(textPass.getText().isEmpty()){
        textPass.setText(CA.getPasswordUsuario());
        textPass.setForeground(Color.BLACK);
        }
        if(textNombre.getText().isEmpty()){
        textNombre.setText(CA.getNombre());
        textNombre.setForeground(Color.BLACK);
        }
        if(textLastName.getText().isEmpty()){
        textLastName.setText(CA.getApellido());
        textLastName.setForeground(Color.BLACK);
        }
        if(textCell.getText().isEmpty()){
        textCell.setText(CA.getCelular());
        textCell.setForeground(Color.BLACK);
        }
        if(textGmail.getText().equals(CA.getCorreo())){
        textGmail.setText("");
        textGmail.setForeground(Color.RED);
        }
        if(textDirec.getText().isEmpty()){
        textDirec.setText(CA.getDireccion());
        textDirec.setForeground(Color.BLACK);
        }  
    }//GEN-LAST:event_textGmailMousePressed

    private void textDirecMousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_textDirecMousePressed
        if(textUser.getText().isEmpty()){
            textUser.setText(CA.getNombreUsuario());
            textUser.setForeground(Color.BLACK);
        }
        if(textPass.getText().isEmpty()){
        textPass.setText(CA.getPasswordUsuario());
        textPass.setForeground(Color.BLACK);
        }
        if(textNombre.getText().isEmpty()){
        textNombre.setText(CA.getNombre());
        textNombre.setForeground(Color.BLACK);
        }
        if(textLastName.getText().isEmpty()){
        textLastName.setText(CA.getApellido());
        textLastName.setForeground(Color.BLACK);
        }
        if(textCell.getText().isEmpty()){
        textCell.setText(CA.getCelular());
        textCell.setForeground(Color.BLACK);
        }
        if(textGmail.getText().isEmpty()){
        textGmail.setText(CA.getCorreo());
        textGmail.setForeground(Color.BLACK);
        }
        if(textDirec.getText().equals(CA.getDireccion())){
        textDirec.setText("");
        textDirec.setForeground(Color.RED);
        }  
    }//GEN-LAST:event_textDirecMousePressed

    private void textUserMousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_textUserMousePressed
        if(textUser.getText().equals(CA.getNombreUsuario())){
            textUser.setText("");
            textUser.setForeground(Color.RED);
        }
        if(textPass.getText().isEmpty()){
        textPass.setText(CA.getPasswordUsuario());
        textPass.setForeground(Color.BLACK);
        }
        if(textNombre.getText().isEmpty()){
        textNombre.setText(CA.getNombre());
        textNombre.setForeground(Color.BLACK);
        }
        if(textLastName.getText().isEmpty()){
        textLastName.setText(CA.getApellido());
        textLastName.setForeground(Color.BLACK);
        }
        if(textCell.getText().isEmpty()){
        textCell.setText(CA.getCelular());
        textCell.setForeground(Color.BLACK);
        }
        if(textGmail.getText().isEmpty()){
        textGmail.setText(CA.getCorreo());
        textGmail.setForeground(Color.BLACK);
        }
        if(textDirec.getText().isEmpty()){
        textDirec.setText(CA.getDireccion());
        textDirec.setForeground(Color.BLACK);
        }   
    }//GEN-LAST:event_textUserMousePressed

    private void textPassMousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_textPassMousePressed
        if(textUser.getText().isEmpty()){
            textUser.setText(CA.getNombreUsuario());
            textUser.setForeground(Color.BLACK);
        }
        if(textPass.getText().equals(CA.getPasswordUsuario())){
        textPass.setText("");
        textPass.setForeground(Color.RED);
        }
        if(textNombre.getText().isEmpty()){
        textNombre.setText(CA.getNombre());
        textNombre.setForeground(Color.BLACK);
        }
        if(textLastName.getText().isEmpty()){
        textLastName.setText(CA.getApellido());
        textLastName.setForeground(Color.BLACK);
        }
        if(textCell.getText().isEmpty()){
        textCell.setText(CA.getCelular());
        textCell.setForeground(Color.BLACK);
        }
        if(textGmail.getText().isEmpty()){
        textGmail.setText(CA.getCorreo());
        textGmail.setForeground(Color.BLACK);
        }
        if(textDirec.getText().isEmpty()){
        textDirec.setText(CA.getDireccion());
        textDirec.setForeground(Color.BLACK);
        }  
    }//GEN-LAST:event_textPassMousePressed

    private void botonActualizarMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_botonActualizarMouseClicked
        showPanel(new empEditarUser(CA));
    }//GEN-LAST:event_botonActualizarMouseClicked

    private void botonActualizarMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_botonActualizarMouseEntered
        botonActualizar.setBackground(new Color(240,148,177));
        actualizar.setForeground(Color.black);
    }//GEN-LAST:event_botonActualizarMouseEntered

    private void botonActualizarMouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_botonActualizarMouseExited
        botonActualizar.setBackground(new Color(235,107,67));
        actualizar.setForeground(Color.white);
    }//GEN-LAST:event_botonActualizarMouseExited


    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JLabel actualizar;
    private javax.swing.JLabel apellido;
    private javax.swing.JPanel bg;
    private javax.swing.JPanel botonAceptar;
    private javax.swing.JPanel botonActualizar;
    private javax.swing.JLabel celular;
    private javax.swing.JLabel contraseña;
    private javax.swing.JLabel correo;
    private javax.swing.JLabel datosActuales1;
    private javax.swing.JLabel dirrecion;
    private javax.swing.JLabel guardarCambios;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JSeparator jSeparator1;
    private javax.swing.JSeparator jSeparator2;
    private javax.swing.JLabel nombre;
    private javax.swing.JTextField textCell;
    private javax.swing.JTextField textDirec;
    private javax.swing.JTextField textGmail;
    private javax.swing.JTextField textLastName;
    private javax.swing.JTextField textNombre;
    private javax.swing.JTextField textPass;
    private javax.swing.JTextField textUser;
    private javax.swing.JLabel user;
    // End of variables declaration//GEN-END:variables
}
