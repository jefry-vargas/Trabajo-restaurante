
package AppBurguerUniverse;

import java.util.ArrayList;

class Bebidas extends Comida{

    public Bebidas(String Tipo, int cant, double precio, ArrayList<Comida> lista) {
        super(Tipo, cant, precio);
        lista.add(this);
    }

    public Bebidas(String Tipo, int cant, double precio) {
        super(Tipo, cant, precio);
    }
}