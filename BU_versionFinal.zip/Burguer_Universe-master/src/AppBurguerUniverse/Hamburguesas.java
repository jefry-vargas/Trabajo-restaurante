
package AppBurguerUniverse;

import java.util.ArrayList;


public class Hamburguesas extends Comida{

    public Hamburguesas(String Tipo, int cant, double precio, ArrayList<Comida> lista) {
        super(Tipo, cant, precio);
        lista.add(this);
    }

    public Hamburguesas(String Tipo, int cant, double precio) {
        super(Tipo, cant, precio);
    }
}