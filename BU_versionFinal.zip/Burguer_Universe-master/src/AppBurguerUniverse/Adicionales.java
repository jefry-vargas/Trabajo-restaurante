
package AppBurguerUniverse;

import java.util.ArrayList;

class Adicionales extends Comida {

    public Adicionales(String Tipo, int cant, double precio, ArrayList<Comida> lista) {
        super(Tipo, cant, precio);
        lista.add(this);
    }

    public Adicionales(String Tipo, int cant, double precio) {
        super(Tipo, cant, precio);
    }
}