
package AppBurguerUniverse;

import java.util.ArrayList;

public class  Inventario {

    private static ArrayList<Comida> listatotalInventario;

    
    public Inventario() {
       this.listatotalInventario= new ArrayList<>();  
    }

    public static boolean verificarConInventario (String tipo, int cant){    
        for (Comida x : Inventario.listatotalInventario){
            if (x.getTipo().equals(tipo)){
                if(x.getCant()>=cant){
                    x.setCant(x.getCant()-cant);
                    return true;
                }
            }
        }
        return false;
    }
    
    public static void reabastecerInventario(String tipo, int can){
        double gastosinventario=0;
        String SEL=tipo;
        int cant=can;
        for (Comida x:Inventario.listatotalInventario){
            if(x.getTipo().equals(SEL)){
                x.setCant(x.getCant()+cant);
                gastosinventario+=(x.getPrecioCompra()*cant);}}
        Contabilidad.gastosTotales(gastosinventario);
    }
    
    public static ArrayList<Hamburguesas> getHamburguesas(){
        ArrayList<Hamburguesas> lista = new ArrayList<>();
        for(Comida x : listatotalInventario){
            if(x instanceof Hamburguesas){
                lista.add((Hamburguesas)x);
            }
        }
        return lista;
    }
    
    public static ArrayList<Bebidas> getBebidas(){
        ArrayList<Bebidas> lista = new ArrayList<>();
        for(Comida x : listatotalInventario){
            if(x instanceof Bebidas){
                lista.add((Bebidas)x);
            }
        }
        return lista;
    }
    
    public static ArrayList<Adicionales> getAdicionales(){
        ArrayList<Adicionales> lista = new ArrayList<>();
        for(Comida x : listatotalInventario){
            if(x instanceof Adicionales){
                lista.add((Adicionales)x);
            }
        }
        return lista;
    }

    public static ArrayList<Comida> getListatotalInventario() {
        return listatotalInventario;
    }
}