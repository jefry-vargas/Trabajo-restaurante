
package AppBurguerUniverse;

import java.util.ArrayList;

public class Contabilidad {
    
    private static double gananciasTotales;
    private static double gastosTotales;
    private static double presupuestoactualesBurguer;
    private static ArrayList<Facturacion> listaFacturas;

    public Contabilidad (){
        gananciasTotales =0;
        gastosTotales=0;
        presupuestoactualesBurguer=500000;
        listaFacturas= new ArrayList<>();
    }
    
    public static void guardarFactura(Facturacion f){
        listaFacturas.add(f);
        gananciasTotales+=f.getMontoaPagar_conIva();
        presupuestoactualesBurguer+=f.getMontoaPagar_conIva();
    }

    public static void gastosTotales (double gastosInventario){
        gastosTotales+=gastosInventario;
        presupuestoactualesBurguer-=gastosInventario;
        
    }

    public static void actualizarFondos(double x){
        presupuestoactualesBurguer+=x; 
    }

    public static double getPresupuestoactualesBurguer() {
        return presupuestoactualesBurguer;
    }

    public static ArrayList<Facturacion> getListaFacturas() {
        return listaFacturas;
    }

    public static double getGananciasTotales() {
        return gananciasTotales;
    }

    public static double getGastosTotales() {
        return gastosTotales;
    }
    
}