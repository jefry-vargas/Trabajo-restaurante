
package AppBurguerUniverse;

import java.util.ArrayList;

public class Facturacion {
    
    private String cliente;
    private String nombre;
    private int numFactura;
    private double montoaPagar;
    private double montoaPagar_conIva;
    private ArrayList<Comida> listaPedido;


    public Facturacion(int numFactura, Cliente cliente) {
        this.cliente = cliente.getNombre()+" "+cliente.getApellido();
        this.nombre = cliente.getNombre();
        this.montoaPagar=cliente.getCostoPedido();
        this.numFactura=numFactura;
        this.montoaPagar_conIva=(cliente.getCostoPedido()*0.19)+cliente.getCostoPedido();
        this.listaPedido=cliente.getListaPedidoComprado();
    }
    
    public void efectuar_pago(Cliente cliente,int cantidad_cuotas,medioPago mediodepago ) {
        double monto_aPagar = this.montoaPagar_conIva;
            if (monto_aPagar>mediodepago.getSaldodisponible()){}
            else { 
                switch(mediodepago){
                    case EFECTIVO ->{cliente.getTarjeta().setSaldodisponible(cliente.getTarjeta().getSaldodisponible()-monto_aPagar);}   
                    case TARJETACREDITO ->{
                        switch(cantidad_cuotas){
                            case 1 ->{cliente.getTarjeta().setSaldodisponible(cliente.getTarjeta().getSaldodisponible()-monto_aPagar);}
                            case 2 ->{cliente.getTarjeta().setSaldodisponible(cliente.getTarjeta().getSaldodisponible()-(((monto_aPagar/2)*0.2)+monto_aPagar/2));
                            this.montoaPagar_conIva=(((monto_aPagar/2)*0.2)+monto_aPagar/2);}
                            case 3 ->{cliente.getTarjeta().setSaldodisponible(cliente.getTarjeta().getSaldodisponible()-(((monto_aPagar/3)*0.3)+monto_aPagar/3));
                            this.montoaPagar_conIva=(((monto_aPagar/3)*0.3)+monto_aPagar/3);}
                            case 4 ->{cliente.getTarjeta().setSaldodisponible(cliente.getTarjeta().getSaldodisponible()-(((monto_aPagar/4)*0.4)+monto_aPagar/4));
                            this.montoaPagar_conIva=(((monto_aPagar/4)*0.4)+monto_aPagar/4);}
                            case 5 ->{cliente.getTarjeta().setSaldodisponible(cliente.getTarjeta().getSaldodisponible()-(((monto_aPagar/5)*0.5)+monto_aPagar/5));
                            this.montoaPagar_conIva=(((monto_aPagar/5)*0.5)+monto_aPagar/5);}
                            case 6 ->{cliente.getTarjeta().setSaldodisponible(cliente.getTarjeta().getSaldodisponible()-(((monto_aPagar/6)*0.6)+monto_aPagar/6));
                            this.montoaPagar_conIva=(((monto_aPagar/6)*0.6)+monto_aPagar/6);}
                        }
                    }
                    case TARJETADEBITO ->{cliente.getTarjeta().setSaldodisponible(cliente.getTarjeta().getSaldodisponible()-monto_aPagar);}
                }
            }
    }

    public double getMontoaPagar() {
        return montoaPagar;
    }

    public double getMontoaPagar_conIva() {
        
        return montoaPagar_conIva ;
    }

    public String getCliente() {
        return cliente;
    }

    public int getNumFactura() {
        return numFactura;
    }

    public ArrayList<Comida> getListaPedido() {
        return listaPedido;
    }
    public void imprimirRecibo(){
        javax.swing.JOptionPane.showMessageDialog(null, "Compra Realizada\n"+
                    "Numero de factura  =  "+this.getNumFactura()+"\n"
                    +"Cliente  =  "+this.getCliente()
                    +"\nValor  =  "+this.getMontoaPagar()
                    +"\nIVA  =  19%"
                    +"\nValor Total  =  "+this.getMontoaPagar_conIva()
                    +"\n"+"Gracias por su compra :)"
            );
    }

    public void setMontoaPagar(double montoaPagar) {
        this.montoaPagar = montoaPagar;
    }

    public String getNombre() {
        return nombre;
    }
    
    
}