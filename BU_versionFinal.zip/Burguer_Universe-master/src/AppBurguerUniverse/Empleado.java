
package AppBurguerUniverse;

import java.util.ArrayList;

public class Empleado extends Usuario {

    // CONSTRUCTOR 
    public Empleado(String nombreUsuario, String passwordUsuario, String nombre, String apellido,
            String celular, String correo, String direcciondeenvio, ArrayList<Usuario> listaTotalUsuario){
        super(nombreUsuario, passwordUsuario, nombre, apellido, celular, correo, direcciondeenvio);
        listaTotalUsuario.add(this);
    }
     public Empleado(String nombreUsuario, String passwordUsuario, String nombre, String apellido,
            String celular, String correo, String direcciondeenvio){
        super(nombreUsuario, passwordUsuario, nombre, apellido, celular, correo, direcciondeenvio);    
    }

    public void consultarInventario() {
        Inventario.getListatotalInventario();
    }
    
    @Override
    public String toString() {
        return "Empleado{" +"nombreUsuario=" + nombreUsuario + ", passwordUsuario=" + passwordUsuario + ", nombre=" + nombre + ", apellido=" + apellido + ", celular=" + celular + ", correo=" + correo + ", direccion=" + direccion+"\n"+ '}';
    }    
}