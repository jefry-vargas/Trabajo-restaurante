
package AppBurguerUniverse;

public enum medioPago {
    TARJETACREDITO("","",0),
    TARJETADEBITO("","",0),
    EFECTIVO(0); 
    
    private String numerotarjeta;
    private String franquicia;
    private double Saldodisponible;

    private medioPago(double Saldodisponible) {
        this.numerotarjeta=null;
        this.franquicia=null;
        this.Saldodisponible = Saldodisponible;
    }

    
    private medioPago(String numerotarjeta, String franquicia, double Saldodisponible) {
        this.numerotarjeta = numerotarjeta;
        this.franquicia = franquicia;
        this.Saldodisponible = Saldodisponible;
    }

    public String getNumerotarjeta() {
        return numerotarjeta;
    }

    public String getFranquicia() {
        return franquicia;
    }

    public double getSaldodisponible() {
        return Saldodisponible;
    }

    public void setSaldodisponible(double Saldodisponible) {
        this.Saldodisponible = Saldodisponible;
    } 

    public void setNumerotarjeta(String numerotarjeta) {
        this.numerotarjeta = numerotarjeta;
    }

    public void setFranquicia(String franquicia) {
        this.franquicia = franquicia;
    }   
}