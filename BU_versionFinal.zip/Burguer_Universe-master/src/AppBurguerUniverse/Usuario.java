package AppBurguerUniverse;

import java.util.ArrayList;

public abstract class Usuario {
 
    // ATRIBUTOS
    protected String nombreUsuario;
    protected String passwordUsuario;
    protected String nombre;
    protected String apellido;
    protected String celular;
    protected String correo;
    protected String direccion;
      
    
    // CONSTRUCTOR      
    
    public Usuario() {
    }

    public Usuario(String nombreUsuario, String passwordUsuario, String nombre, String apellido, String celular, String correo, String direccion) {
        this.nombreUsuario = nombreUsuario;
        this.passwordUsuario = passwordUsuario;
        this.nombre = nombre;
        this.apellido = apellido;
        this.celular = celular;
        this.correo = correo;
        this.direccion = direccion;
    }

    // METODOS

    public String getNombreUsuario() {
        return nombreUsuario;
    }

    public void setNombreUsuario(String nombreUsuario) {
        this.nombreUsuario = nombreUsuario;
    }

    public String getPasswordUsuario() {
        return passwordUsuario;
    }

    public void setPasswordUsuario(String passwordUsuario) {
        this.passwordUsuario = passwordUsuario;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getApellido() {
        return apellido;
    }

    public void setApellido(String apellido) {
        this.apellido = apellido;
    }

    public String getCelular() {
        return celular;
    }

    public void setCelular(String celular) {
        this.celular = celular;
    }

    public String getCorreo() {
        return correo;
    }

    public void setCorreo(String correo) {
        this.correo = correo;
    }

    public String getDireccion() {
        return direccion;
    }

    public void setDireccion(String direccion) {
        this.direccion = direccion;
    }
    
    public static int verifyTipoUsuario(ArrayList<Usuario> lista, String user, String pass) {
       for (Usuario x: lista){
          if (x.getNombreUsuario().equals(user) && x.getPasswordUsuario().equals(pass)){
              if(x instanceof Administrador){
                  return 1;
              }
              else if (x instanceof Empleado){
                  return 2;
              }
              else if (x instanceof Cliente){
                  return 3;
              }
            }  
        }
       return 0;
    }
    public static Usuario devolverUsuario(ArrayList<Usuario> lista, String user, String pass) {
       for (Usuario x: lista){
          if (x.getNombreUsuario().equals(user) && x.getPasswordUsuario().equals(pass)){
              return x;
          }
       }
       return null;
    }
}