
package AppBurguerUniverse;

import Interfaz.login;

public class Main { 
    public static void main (String [ ] args){
        BaseDatosBurguerUniverse BaseDatosBurguer= new BaseDatosBurguerUniverse();
        Inventario InventarioBurguer = new Inventario();
        Contabilidad contabilidadBurgueU = new Contabilidad();
        
        Administrador admin1=new Administrador("A","1","MARIA JOSE","DIAZ","3124634067","diazadmin19@gmail.com","CALLE 79 ",BaseDatosBurguer.getLeistaTotalUsuarios());  
        Empleado empleado1=new Empleado("E","1","JEFRY","VARGAS","3124634067","jefryuser@gmail.com","CALLE 79 ",BaseDatosBurguer.getLeistaTotalUsuarios());
        Cliente cliente1 = new Cliente ("C","1","RICARDO","PRIETO","3124634067","ricardo123@gmail.com","CALLE 79 ",BaseDatosBurguer.getLeistaTotalUsuarios(),"TarjetaCredito");
        cliente1.getTarjeta().setFranquicia("Mastercard");
        cliente1.getTarjeta().setNumerotarjeta("123456789");
        cliente1.getTarjeta().setSaldodisponible(100000);
    
        Hamburguesas H1 = new Hamburguesas("Hamburguesa_CarneParrilla", 10, 20000, InventarioBurguer.getListatotalInventario());
        Hamburguesas H2 = new Hamburguesas("Hamburguesa_Ranchera", 10, 20000, InventarioBurguer.getListatotalInventario());
        Hamburguesas H3 = new Hamburguesas("Hamburguesa_Casa", 10, 20000, InventarioBurguer.getListatotalInventario());
        Hamburguesas H4 = new Hamburguesas("Hamburguesa_Philadelphia", 10, 20000, InventarioBurguer.getListatotalInventario());
        Hamburguesas H5 = new Hamburguesas("PolloApanado", 10, 20000, InventarioBurguer.getListatotalInventario());
        Hamburguesas H6 = new Hamburguesas("Hamburguesa_PolloParrilla", 10, 20000, InventarioBurguer.getListatotalInventario());
        Hamburguesas H7 = new Hamburguesas("Hamburguesa_Lentejas", 10, 25000, InventarioBurguer.getListatotalInventario());
        Hamburguesas H8 = new Hamburguesas("Hamburguesa_Soya", 10, 25000, InventarioBurguer.getListatotalInventario());
        Hamburguesas H9 = new Hamburguesas("Hamburguesa_Portobello", 10, 25000, InventarioBurguer.getListatotalInventario());
        
        Bebidas B1= new Bebidas("CocaCola", 10, 5000, InventarioBurguer.getListatotalInventario());
        Bebidas B2= new Bebidas("Uva", 10, 5000, InventarioBurguer.getListatotalInventario());
        Bebidas B3= new Bebidas("Sprite", 10, 5000, InventarioBurguer.getListatotalInventario());
        Bebidas B4= new Bebidas("Agua_Gas", 10, 5000, InventarioBurguer.getListatotalInventario());
        Bebidas B5= new Bebidas("Agua_Natural", 10, 5000, InventarioBurguer.getListatotalInventario());
        Bebidas B6= new Bebidas("Corona", 10, 8000, InventarioBurguer.getListatotalInventario());
        Bebidas B7= new Bebidas("Aguila", 10, 8000, InventarioBurguer.getListatotalInventario());
        Bebidas B8= new Bebidas("Stella_Artois", 10, 8000, InventarioBurguer.getListatotalInventario());
        
        Adicionales A1 = new Adicionales("PorcionPequeña_PapasCasco", 10, 6000, InventarioBurguer.getListatotalInventario());
        Adicionales A2 = new Adicionales("PorcionMediana_PapasCasco", 10, 8000, InventarioBurguer.getListatotalInventario());
        Adicionales A3 = new Adicionales("PorcionGrande_PapasCasco", 10, 10000, InventarioBurguer.getListatotalInventario());
        Adicionales A4 = new Adicionales("PorcionPequeña_PapasCheeseBacon", 10, 6000, InventarioBurguer.getListatotalInventario());
        Adicionales A5 = new Adicionales("PorcionMediana_PapasCheeseBacon", 10, 8000, InventarioBurguer.getListatotalInventario());
        Adicionales A6 = new Adicionales("PorcionGrande_PapasCheeseBacon", 10, 10000, InventarioBurguer.getListatotalInventario());
        Adicionales A7 = new Adicionales("PorcionPequeña_PapasRizadas", 10, 6000, InventarioBurguer.getListatotalInventario());
        Adicionales A8 = new Adicionales("PorcionMediana_PapasRizadas", 10, 8000, InventarioBurguer.getListatotalInventario());
        Adicionales A9 = new Adicionales("PorcionGrande_PapasRizadas", 10, 10000, InventarioBurguer.getListatotalInventario());
        
        new login().setVisible(true);
    }
}