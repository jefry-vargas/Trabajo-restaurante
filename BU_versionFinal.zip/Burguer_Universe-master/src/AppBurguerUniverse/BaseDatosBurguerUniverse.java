
package AppBurguerUniverse;

import java.util.ArrayList;

public class BaseDatosBurguerUniverse {
    //LISTA DE USUARIOS
    private static ArrayList<Usuario>listaTotalUsuarios;
    
    //CONSTRUCTOR
    public BaseDatosBurguerUniverse() {
        listaTotalUsuarios=new ArrayList<>();
    }
    
    //METODOS
    public void crearUsuario(ArrayList<Usuario> listaTotalUsuarios,int tipo,String nombreUsuario, String passwordUsuario, String nombre, String apellido,
            String celular, String correo, String direccion, String tarjeta) { 
        if(tipo==1){
            listaTotalUsuarios.add(new Administrador(nombreUsuario,passwordUsuario, nombre, apellido, celular, correo, direccion));
        }
        else if(tipo==2){
            listaTotalUsuarios.add(new Empleado(nombreUsuario,passwordUsuario, nombre, apellido, celular, correo, direccion));
        }
        else if(tipo==3){
            listaTotalUsuarios.add(new Cliente(nombreUsuario,passwordUsuario, nombre, apellido, celular, correo, direccion, tarjeta));
        }
    }
    
    public ArrayList<Usuario> listaPorTipoPersonal(int tipo){
        ArrayList<Usuario> lista=null;
        for(Usuario x: listaTotalUsuarios){
            if (tipo==1){
                if(x instanceof Administrador){
                        lista.add(x);
                }
            }
            else if(tipo==2){
                if(x instanceof Empleado){
                    lista.add(x);
                }
            }
            else if(tipo==3){
                if(x instanceof Cliente){
                    lista.add(x);
                }
            }
        }
        return lista;
    }
    public static int verifyTipoUsuario(ArrayList<Usuario> lista, String user, String pass) {
       for (Usuario x: lista){
          if (x.getNombreUsuario().equals(user) && x.getPasswordUsuario().equals(pass)){
              if(x instanceof Administrador){
                  return 1;
              }
              else if (x instanceof Empleado){
                  return 2;
              }
              else if (x instanceof Cliente){
                  return 3;
              }
            }  
        }
       return 0;
    }
    public static String verifyTipoUsuario_S(ArrayList<Usuario> lista, String user, String pass) {
       for (Usuario x: lista){
          if (x.getNombreUsuario().equals(user) && x.getPasswordUsuario().equals(pass)){
              if(x instanceof Administrador){
                  return "Administrador";
              }
              else if (x instanceof Empleado){
                  return "Empleaod";
              }
              else if (x instanceof Cliente){
                  return "Cliente";
              }
            }  
        }
       return "";
    }
    
    public int cantidadUsuarios(){
        int x= listaTotalUsuarios.size()+1;
        return x;
    }

    public static ArrayList<Usuario> getListaTotalUsuarios(){ 
    return listaTotalUsuarios;
    } 
    public ArrayList<Usuario> getLeistaTotalUsuarios(){ 
    return listaTotalUsuarios;
    }  
    
    public static void eliminarUsuario(String user){
        for(Usuario x: listaTotalUsuarios){
            if(x.getNombreUsuario().equals(user)){
                listaTotalUsuarios.remove(x);
            }
        }
    }
}