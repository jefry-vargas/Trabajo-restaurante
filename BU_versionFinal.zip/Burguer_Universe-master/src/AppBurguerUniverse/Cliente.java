package AppBurguerUniverse;

import java.util.ArrayList;

public class Cliente extends Usuario {
    
    private static ArrayList<Comida> listaPedidoCliente;
    private static ArrayList<Comida> listaPedidoComprado;
    private static medioPago tarjeta;
 
    // CONSTRUCTOR    
    public Cliente(String nombreUsuario, String passwordUsuario, String nombre, String apellido,
            String celular, String correo, String direcciondeenvio, ArrayList<Usuario> listaTotalUsuario, 
            String mediodepago){
        super(nombreUsuario, passwordUsuario, nombre, apellido, celular, correo, direcciondeenvio);
        listaTotalUsuario.add(this);
        listaPedidoCliente = new ArrayList<>();
        listaPedidoComprado = new ArrayList<>();
        this.tarjeta=this.tipoTarjeta(mediodepago);
    }
    
    public Cliente(String nombreUsuario, String passwordUsuario, String nombre, String apellido,
             String celular, String correo, String direcciondeenvio, String mediodepago){
        super(nombreUsuario, passwordUsuario, nombre, apellido, celular, correo, direcciondeenvio);
        this.tarjeta=this.tipoTarjeta(mediodepago);
    }
    //METODOS
    public static void modificarUsuario(ArrayList<Usuario> listaTotalUsuarios,String nombreUserViejo,String userNuevo, String pass, String nombre, String apellido,
            String celular, String correo, String direccion){
        for (Usuario x : listaTotalUsuarios){
            if (x.getNombreUsuario().equals(nombreUserViejo)){
                x.setNombreUsuario(userNuevo);
                x.setPasswordUsuario(pass);
                x.setNombre(nombre);
                x.setApellido(apellido);
                x.setCelular(celular);
                x.setCorreo(correo);
                x.setDireccion(direccion);
            }
        }
    }
 
    public void realizarpedido(int tipo, int can){    
    int SEL=tipo;
    int cant=can;
        switch(SEL) {
            case 1 -> { Hamburguesas H1 = new Hamburguesas("Hamburguesa_CarneParrilla", cant, 20000, listaPedidoCliente);}
            case 2 -> { Hamburguesas H2 = new Hamburguesas("Hamburguesa_Ranchera", cant, 20000, listaPedidoCliente);}
            case 3 -> { Hamburguesas H3 = new Hamburguesas("Hamburguesa_Casa", cant, 20000, listaPedidoCliente);}
            case 4 -> { Hamburguesas H4 = new Hamburguesas("Hamburguesa_Philadelphia", cant, 20000, listaPedidoCliente);}
            case 5 -> { Hamburguesas H5 = new Hamburguesas("PolloApanado", cant, 20000, listaPedidoCliente);}
            case 6 -> { Hamburguesas H6 = new Hamburguesas("Hamburguesa_PolloParrilla", cant, 20000, listaPedidoCliente);} 
            case 7 -> { Hamburguesas H7 = new Hamburguesas("Hamburguesa_Lentejas", cant, 25000, listaPedidoCliente);}
            case 8 -> { Hamburguesas H8 = new Hamburguesas("Hamburguesa_Soya", cant, 25000, listaPedidoCliente);}
            case 9 -> { Hamburguesas H9 = new Hamburguesas("Hamburguesa_Portobello", cant, 25000, listaPedidoCliente);}
            case 10 -> { Bebidas B1= new Bebidas("CocaCola", cant, 5000, listaPedidoCliente);}
            case 11 -> { Bebidas B2= new Bebidas("Uva", cant, 5000, listaPedidoCliente);}
            case 12 -> { Bebidas B3= new Bebidas("Sprite", cant, 5000, listaPedidoCliente);}
            case 13 -> { Bebidas B4= new Bebidas("Agua_Gas", cant, 5000, listaPedidoCliente);}
            case 14 -> { Bebidas B5= new Bebidas("Agua_Natural", cant, 5000, listaPedidoCliente);}
            case 15 -> { Bebidas B6= new Bebidas("Corona", cant, 8000, listaPedidoCliente);}
            case 16 -> { Bebidas B7= new Bebidas("Aguila", cant, 8000, listaPedidoCliente);}
            case 17 -> { Bebidas B8= new Bebidas("Stella_Artois", cant, 8000, listaPedidoCliente);}
            case 18 -> { Adicionales A1 = new Adicionales("PorcionPequeña_PapasCasco", cant, 6000, listaPedidoCliente);}
            case 19 -> { Adicionales A2 = new Adicionales("PorcionMediana_PapasCasco", cant, 8000, listaPedidoCliente);}
            case 20 -> { Adicionales A3 = new Adicionales("PorcionGrande_PapasCasco", cant, 10000, listaPedidoCliente);}
            case 21 -> { Adicionales A4 = new Adicionales("PorcionPequeña_PapasCheeseBacon", cant, 6000, listaPedidoCliente);}
            case 22 -> { Adicionales A5 = new Adicionales("PorcionMediana_PapasCheeseBacon", cant, 8000, listaPedidoCliente);}
            case 23 -> { Adicionales A6 = new Adicionales("PorcionGrande_PapasCheeseBacon", cant, 10000, listaPedidoCliente);}
            case 24 -> { Adicionales A7 = new Adicionales("PorcionPequeña_PapasRizadas", cant, 6000, listaPedidoCliente);}
            case 25 -> { Adicionales A8 = new Adicionales("PorcionMediana_PapasRizadas", cant, 8000, listaPedidoCliente);}
            case 26 -> { Adicionales A9 = new Adicionales("PorcionGrande_PapasRizadas", cant, 10000, listaPedidoCliente);}    
        }  
        for(Comida x: listaPedidoCliente){
            listaPedidoComprado.add(x);
        }
    }
        
    public void cancelarpedido(){
        for(Comida x:this.getListPedidoCliente()){
            for(Comida y: Inventario.getListatotalInventario()){
                if(x.getTipo().equals(y.getTipo())){
                        y.setCant(y.getCant()+x.getCant());
                    }
            }
        }
        listaPedidoCliente.removeAll(listaPedidoCliente);
    }
    public void borrarpedido(){
        listaPedidoCliente.removeAll(listaPedidoCliente);
    }
    public void cancelarpedido(String tipo){
        for(Comida x:this.getListPedidoCliente()){
            if(tipo.equals(x.getTipo())){
                for(Comida y: Inventario.getListatotalInventario()){
                    if(x.getTipo().equals(y.getTipo())){
                        y.setCant(y.getCant()+x.getCant());
                    }
                }
            }
            listaPedidoCliente.remove(x);
        }   
    }

    public static ArrayList<Comida> getListaPedidoCliente() {
        return listaPedidoCliente;
    }
    public ArrayList<Comida> getListPedidoCliente() {
        return listaPedidoCliente;
    }
    
    public double getCostoPedido(){
        double costo=0;
        for(Comida x: listaPedidoCliente){
            costo+=x.getPrecioAcumulado();
        }
        return costo;
    }
    public static medioPago tipoTarjeta(String mediodepago){
        if(mediodepago.equals("TarjetaCredito")){
            return medioPago.TARJETACREDITO;
        }
        else if(mediodepago.equals("TarjetaDebito")){
            return medioPago.TARJETADEBITO;
        }
        else{return medioPago.EFECTIVO;}
    }

    public medioPago getTarjeta() {
        return tarjeta;
    }
    public static medioPago getTajeta() {
        return tarjeta;
    }

    public ArrayList<Comida> getListaPedidoComprado() {
        return listaPedidoComprado;
    }

    @Override
    public String toString() {
        return "Cliente{" +"nombreUsuario=" + nombreUsuario + ", \npasswordUsuario=" + passwordUsuario +
                ", \nnombre=" + nombre + ", \napellido=" + apellido + ", \ncelular=" + celular +
                ", \ncorreo=" + correo + ", \ndireccion=" + direccion+"\ntarjeta= "+this.tarjeta +
                "\nsaldo tarjeta= "+this.tarjeta.getSaldodisponible()+
                "\nfranquicia= "+this.tarjeta.getFranquicia()+
                "\nnumero tarjeta="+this.tarjeta.getNumerotarjeta()+'}';
    }    
}