
package AppBurguerUniverse;
import java.util.ArrayList;


public class Administrador extends Usuario {

    // CONSTRUCTOR
    
    public Administrador() {
    }

    public Administrador(String nombreUsuario, String passwordUsuario, String nombre, String apellido, String celular, String correo, String direcciondeenvio, ArrayList<Usuario> listaTotalUsuario) {
        super(nombreUsuario, passwordUsuario, nombre, apellido, celular, correo, direcciondeenvio);
        listaTotalUsuario.add(this);
    }
    
     public Administrador(String nombreUsuario, String passwordUsuario, String nombre, String apellido,
           String celular, String correo, String direcciondeenvio) {
        super(nombreUsuario, passwordUsuario, nombre, apellido, celular, correo, direcciondeenvio);
    }

    public static void crearUsuario(ArrayList<Usuario> listaTotalUsuarios,int tipo,String nombreUsuario, String passwordUsuario, String nombre, String apellido,
            String celular, String correo, String direccion,String tarjeta) { 
        switch (tipo) {
            case 1 -> listaTotalUsuarios.add(new Administrador(nombreUsuario,passwordUsuario, nombre, apellido, celular, correo, direccion));
            case 2 -> listaTotalUsuarios.add(new Empleado(nombreUsuario,passwordUsuario, nombre, apellido, celular, correo, direccion));
            case 3 -> listaTotalUsuarios.add(new Cliente(nombreUsuario,passwordUsuario, nombre, apellido, celular, correo, direccion, tarjeta));
        }
    }
    

    public void consultarInventarioadmin(){
       Inventario.getListatotalInventario(); 
    }
    
    public static void actualizarInventarioadmin(String tipo, int can){
       Inventario.reabastecerInventario(tipo,can); 
    }
      
    public static void modificarUsuario(ArrayList<Usuario> listaTotalUsuarios,String nombreUserViejo,String userNuevo, String pass, String nombre, String apellido,
            String celular, String correo, String direccion){
        for (Usuario x : listaTotalUsuarios){
            if (x.getNombreUsuario().equals(nombreUserViejo)){
                x.setNombreUsuario(userNuevo);
                x.setPasswordUsuario(pass);
                x.setNombre(nombre);
                x.setApellido(apellido);
                x.setCelular(celular);
                x.setCorreo(correo);
                x.setDireccion(direccion);
            }
        }
    }
    
    public static boolean comprobarUserPorTipo(String user){
        for(Usuario x:BaseDatosBurguerUniverse.getListaTotalUsuarios()){
            if(x.getNombreUsuario().equals(user)){
                return false;
            }
        }
        return true;
    } 
    
    public Usuario consultarUsuarios(String User){
        for(Usuario x: BaseDatosBurguerUniverse.getListaTotalUsuarios()){
            if(x.getNombreUsuario().equals(User)){
                return x;
            }
        }
        return null;
    }
    public void eliminarUsuario(String user){
        BaseDatosBurguerUniverse.eliminarUsuario(user);
    }
    
    @Override
    public String toString() {
        return "Administrador{"+ "nombreUsuario=" + nombreUsuario + ", passwordUsuario=" + passwordUsuario + ", nombre=" + nombre + ", apellido=" + apellido + ", celular=" + celular + ", correo=" + correo + ", direccion=" + direccion + "\n"+'}';
    }        
} 

//    public void agregarPlato(String TipoAlimento){
//       
//    switch (TipoAlimento) {
//        case ("HAMBURGUESA"):
//            String newhamburguer=JOptionPane.showInputDialog("INSERTE LA NUEVA HAMBURGUESA PARA AÑADIR AL MENU"); 
//            int newvalor=Integer.parseInt(JOptionPane.showInputDialog("INSERTE EL VALOR QUE TENDRA ESTA HAMBURGUESA EN EL MENU"));
//            listaHamburguesas.add(new Hamburguesas(newhamburguer ,newvalor));
//            break;
//        case ("BEBIDA"):
//            String newbebir=JOptionPane.showInputDialog("INSERTE LA NUEVA BEBIDA PARA AÑADIR AL MENU"); 
//            int newval=Integer.parseInt(JOptionPane.showInputDialog("INSERTE EL VALOR QUE TENDRA ESTA BEBIDA EN EL MENU"));
//            listaBebidas.add(new Bebidas(newbebir ,newval));
//            break;
//        case ("ADICIONALES"):
//            String newadi=JOptionPane.showInputDialog("INSERTE LA NUEVA ADICION PARA AÑADIR AL MENU"); 
//            int peq=Integer.parseInt(JOptionPane.showInputDialog("INSERTE EL VALOR QUE TENDRA LA PORCION PEQUEÑA PARA ESTA ADICION EN EL MENU"));
//            int med=Integer.parseInt(JOptionPane.showInputDialog("INSERTE EL VALOR QUE TENDRA LA PORCION PEQUEÑA PARA ESTA ADICION EN EL MENU"));
//            int gra=Integer.parseInt(JOptionPane.showInputDialog("INSERTE EL VALOR QUE TENDRA LA PORCION PEQUEÑA PARA ESTA ADICION EN EL MENU"));
//            listaAdicionales.add(new Adicionales("PorcionPequeña"+newadi ,peq));
//            listaAdicionales.add(new Adicionales("PorcionMediana"+newadi ,med));
//            listaAdicionales.add(new Adicionales("PorcionGrande"+newadi ,gra));
//            break;
//        default:
//            break;
//    }
//    }
 