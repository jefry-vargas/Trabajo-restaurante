
package AppBurguerUniverse;

public abstract class Comida {
    protected String Tipo;
    protected int cant;
    protected double precioUnidad;
    protected double precioAcumulado;
    protected double precioCompra;

    public Comida(String Tipo, int cant, double precio) {
        this.Tipo = Tipo;
        this.cant = cant;
        this.precioUnidad= precio;
        this.precioAcumulado = (cant*precio);
        this.precioCompra= (precio/2);
    }

    public String getTipo() {
        return Tipo;
    }

    public void setTipo(String Tipo) {
        this.Tipo = Tipo;
    }

    public int getCant() {
        return cant;
    }

    public void setCant(int cant) {
        this.cant = cant;
    }

    public double getPrecioUnidad() {
        return precioUnidad;
    }

    public void setPrecioUnidad(double precioUnidad) {
        this.precioUnidad = precioUnidad;
    }

    public double getPrecioAcumulado() {
        return precioAcumulado;
    }

    public void setPrecioAcumulado(double precioAcumulado) {
        this.precioAcumulado = precioAcumulado;
    }

    public double getPrecioCompra() {
        return precioCompra;
    }

    public void setPrecioCompra(double precioCompra) {
        this.precioCompra = precioCompra;
    }
    
}